var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};

// bb.ts
var bb_exports = {};
__export(bb_exports, {
  ByteBuffer: () => ByteBuffer,
  default: () => bb_default
});
module.exports = __toCommonJS(bb_exports);
var int32 = new Int32Array(1);
var float32 = new Float32Array(int32.buffer);
var int16 = new Int16Array(int32.buffer);
var uint16 = new Uint16Array(int32.buffer);
var uint32 = new Uint32Array(int32.buffer);
var uint8Buffer = new Uint8Array(int32.buffer);
var int8Buffer = new Int8Array(int32.buffer);
var textDecoder;
var textEncoder;
var ArrayBufferType = typeof SharedArrayBuffer !== "undefined" ? SharedArrayBuffer : ArrayBuffer;
var _ByteBuffer = class {
  data;
  index;
  length;
  constructor(data, addViews = false) {
    if (data && !(data instanceof Uint8Array)) {
      throw new Error("Must initialize a ByteBuffer with a Uint8Array");
    }
    this.data = data || new Uint8Array(256);
    this.index = 0;
    this.length = data ? data.length : 0;
  }
  toUint8Array() {
    return this.data.subarray(0, this.length);
  }
  readByte() {
    if (this.index + 1 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    return this.data[this.index++];
  }
  readAlphanumeric() {
    if (!textDecoder) {
      textDecoder = new TextDecoder("utf-8");
    }
    let start = this.index;
    let char = 256;
    const end = this.length - 1;
    while (this.index < end && char > 0) {
      char = this.data[this.index++];
    }
    return String.fromCharCode(...this.data.subarray(start, this.index - 1));
  }
  writeAlphanumeric(contents) {
    if (this.length + 1 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    let index = this.length;
    this._growBy(contents.length);
    const data = this.data;
    let i = 0;
    let code = 0;
    while (i < contents.length) {
      code = data[index++] = contents.charCodeAt(i++);
      if (code > 127)
        throw new Error(`Non-ascii character at char ${i - 1} :${contents}`);
    }
    this.writeByte(0);
  }
  readFloat32() {
    if (this.index + 4 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    uint8Buffer[0] = this.data[this.index++];
    uint8Buffer[1] = this.data[this.index++];
    uint8Buffer[2] = this.data[this.index++];
    uint8Buffer[3] = this.data[this.index++];
    return float32[0];
  }
  readByteArray() {
    let length = this.readVarUint();
    let start = this.index;
    let end = start + length;
    if (end > this.data.length) {
      throw new Error("Read array out of bounds");
    }
    this.index = end;
    let result = new Uint8Array(new ArrayBufferType(length));
    result.set(this.data.subarray(start, end));
    return result;
  }
  readUint32ByteArray() {
    const array = this.readByteArray();
    return new Uint32Array(
      array.buffer,
      0,
      array.length / Uint32Array.BYTES_PER_ELEMENT
    );
  }
  readInt8ByteArray() {
    const array = this.readByteArray();
    return new Int8Array(
      array.buffer,
      0,
      array.length / Int8Array.BYTES_PER_ELEMENT
    );
  }
  readInt16ByteArray() {
    const array = this.readByteArray();
    return new Int16Array(
      array.buffer,
      0,
      array.length / Int16Array.BYTES_PER_ELEMENT
    );
  }
  readInt32ByteArray() {
    const array = this.readByteArray();
    return new Int32Array(
      array.buffer,
      0,
      array.length / Int32Array.BYTES_PER_ELEMENT
    );
  }
  readFloat32ByteArray() {
    const array = this.readByteArray();
    return new Float32Array(
      array.buffer,
      0,
      array.length / Float32Array.BYTES_PER_ELEMENT
    );
  }
  readVarFloat() {
    let index = this.index;
    let data = this.data;
    let length = data.length;
    if (index + 1 > length) {
      throw new Error("Index out of bounds");
    }
    let first = data[index];
    if (first === 0) {
      this.index = index + 1;
      return 0;
    }
    if (index + 4 > length) {
      throw new Error("Index out of bounds");
    }
    let bits = first | data[index + 1] << 8 | data[index + 2] << 16 | data[index + 3] << 24;
    this.index = index + 4;
    bits = bits << 23 | bits >>> 9;
    int32[0] = bits;
    return float32[0];
  }
  readUint32() {
    if (this.index + 4 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    uint8Buffer[0] = this.data[this.index++];
    uint8Buffer[1] = this.data[this.index++];
    uint8Buffer[2] = this.data[this.index++];
    uint8Buffer[3] = this.data[this.index++];
    return uint32[0];
  }
  readUint16() {
    if (this.index + 2 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    uint8Buffer[0] = this.data[this.index++];
    uint8Buffer[1] = this.data[this.index++];
    return uint16[0];
  }
  // This is no longer var uint because the use-case changed and I haven't had time to update all the references
  // This is a uint32 for performance reasons. var uint is very cheap in Go/native languages but very expensive in JavaScript
  // So we opt for the easy route.
  readVarUint() {
    return this.readUint32();
  }
  readInt32() {
    if (this.index + 4 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    uint8Buffer[0] = this.data[this.index++];
    uint8Buffer[1] = this.data[this.index++];
    uint8Buffer[2] = this.data[this.index++];
    uint8Buffer[3] = this.data[this.index++];
    return int32[0];
  }
  readInt16() {
    if (this.index + 2 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    uint8Buffer[0] = this.data[this.index++];
    uint8Buffer[1] = this.data[this.index++];
    return int16[0];
  }
  readInt8() {
    if (this.index + 1 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    uint8Buffer[0] = this.data[this.index++];
    return int8Buffer[0];
  }
  readVarInt() {
    return this.readInt32();
  }
  // This is not a null-terminated string.
  readString() {
    const length = this.readVarUint();
    let start = this.index;
    this.index += length;
    if (!textDecoder) {
      textDecoder = new TextDecoder("utf8");
    }
    return textDecoder.decode(this.data.subarray(start, this.index));
  }
  _growBy(amount) {
    if (this.length + amount > this.data.length) {
      let data = new Uint8Array(
        Math.imul(this.length + amount, _ByteBuffer.WIGGLE_ROOM) << 1
      );
      data.set(this.data);
      this.data = data;
    }
    this.length += amount;
  }
  writeByte(value) {
    let index = this.length;
    this._growBy(1);
    this.data[index] = value;
  }
  writeByteArray(value) {
    this.writeVarUint(value.length);
    let index = this.length;
    this._growBy(value.length);
    this.data.set(value, index);
  }
  writeUint16ByteArray(value) {
    this.writeByteArray(
      new Uint8Array(value.buffer, value.byteOffset, value.byteLength)
    );
  }
  writeUint32ByteArray(value) {
    this.writeByteArray(
      new Uint8Array(value.buffer, value.byteOffset, value.byteLength)
    );
  }
  writeInt8ByteArray(value) {
    this.writeByteArray(
      new Uint8Array(value.buffer, value.byteOffset, value.byteLength)
    );
  }
  writeInt16ByteArray(value) {
    this.writeByteArray(
      new Uint8Array(value.buffer, value.byteOffset, value.byteLength)
    );
  }
  writeInt32ByteArray(value) {
    this.writeByteArray(
      new Uint8Array(value.buffer, value.byteOffset, value.byteLength)
    );
  }
  writeFloat32Array(value) {
    this.writeByteArray(
      new Uint8Array(value.buffer, value.byteOffset, value.byteLength)
    );
  }
  writeVarFloat(value) {
    let index = this.length;
    float32[0] = value;
    let bits = int32[0];
    bits = bits >>> 23 | bits << 9;
    if ((bits & 255) === 0) {
      this.writeByte(0);
      return;
    }
    this._growBy(4);
    let data = this.data;
    data[index] = bits;
    data[index + 1] = bits >> 8;
    data[index + 2] = bits >> 16;
    data[index + 3] = bits >> 24;
  }
  writeFloat32(value) {
    let index = this.length;
    this._growBy(4);
    float32[0] = value;
    this.data.set(uint8Buffer, index);
  }
  writeVarUint(value) {
    this.writeUint32(value);
  }
  writeUint16(value) {
    let index = this.length;
    this._growBy(2);
    uint16[0] = value;
    this.data[index++] = uint8Buffer[0];
    this.data[index++] = uint8Buffer[1];
  }
  writeUint32(value) {
    let index = this.length;
    this._growBy(4);
    uint32[0] = value;
    this.data.set(uint8Buffer, index);
  }
  writeVarInt(value) {
    this.writeInt32(value);
  }
  writeInt8(value) {
    let index = this.length;
    this._growBy(1);
    int8Buffer[0] = value;
    this.data[index++] = uint8Buffer[0];
  }
  writeInt16(value) {
    let index = this.length;
    this._growBy(2);
    int16[0] = value;
    this.data[index++] = uint8Buffer[0];
    this.data[index++] = uint8Buffer[1];
  }
  writeInt32(value) {
    let index = this.length;
    this._growBy(4);
    int32[0] = value;
    this.data.set(uint8Buffer, index);
  }
  writeLowPrecisionFloat(value) {
    this.writeVarInt(Math.round(_ByteBuffer.LOW_PRECISION_VALUE * value));
  }
  readLowPrecisionFloat() {
    return this.readVarInt() / _ByteBuffer.LOW_PRECISION_VALUE;
  }
  writeString(value) {
    var initial_offset = this.length;
    this.writeVarUint(value.length);
    if (!textEncoder) {
      textEncoder = new TextEncoder();
    }
    const offset = this.length;
    this._growBy(value.length * 2 + 5);
    const result = textEncoder.encodeInto(value, this.data.subarray(offset));
    this.length = offset + result.written;
    if (result.written !== value.length) {
      uint32[0] = result.written;
      this.data[initial_offset++] = uint8Buffer[0];
      this.data[initial_offset++] = uint8Buffer[1];
      this.data[initial_offset++] = uint8Buffer[2];
      this.data[initial_offset++] = uint8Buffer[3];
    }
  }
};
var ByteBuffer = _ByteBuffer;
__publicField(ByteBuffer, "WIGGLE_ROOM", 1);
__publicField(ByteBuffer, "LOW_PRECISION_VALUE", 10 ** 3);
var bb_default = ByteBuffer;
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ByteBuffer
});
