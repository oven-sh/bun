var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};

// peechy.ts
var peechy_exports = {};
__export(peechy_exports, {
  ByteBuffer: () => ByteBuffer,
  compileSchema: () => compileSchema,
  compileSchemaCPP: () => compileSchemaCPP,
  compileSchemaCallbackCPP: () => compileSchemaCallbackCPP,
  compileSchemaJS: () => compileSchemaJS,
  compileSchemaSkew: () => compileSchemaSkew,
  compileSchemaSkewTypes: () => compileSchemaSkewTypes,
  compileSchemaTypeScript: () => compileSchemaTypeScript,
  decodeBinarySchema: () => decodeBinarySchema,
  encodeBinarySchema: () => encodeBinarySchema,
  parseSchema: () => parseSchema,
  prettyPrintSchema: () => prettyPrintSchema
});
module.exports = __toCommonJS(peechy_exports);

// bb.ts
var int32 = new Int32Array(1);
var float32 = new Float32Array(int32.buffer);
var int16 = new Int16Array(int32.buffer);
var uint16 = new Uint16Array(int32.buffer);
var uint32 = new Uint32Array(int32.buffer);
var uint8Buffer = new Uint8Array(int32.buffer);
var int8Buffer = new Int8Array(int32.buffer);
var textDecoder;
var textEncoder;
var ArrayBufferType = typeof SharedArrayBuffer !== "undefined" ? SharedArrayBuffer : ArrayBuffer;
var _ByteBuffer = class {
  data;
  index;
  length;
  constructor(data, addViews = false) {
    if (data && !(data instanceof Uint8Array)) {
      throw new Error("Must initialize a ByteBuffer with a Uint8Array");
    }
    this.data = data || new Uint8Array(256);
    this.index = 0;
    this.length = data ? data.length : 0;
  }
  toUint8Array() {
    return this.data.subarray(0, this.length);
  }
  readByte() {
    if (this.index + 1 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    return this.data[this.index++];
  }
  readAlphanumeric() {
    if (!textDecoder) {
      textDecoder = new TextDecoder("utf-8");
    }
    let start = this.index;
    let char = 256;
    const end = this.length - 1;
    while (this.index < end && char > 0) {
      char = this.data[this.index++];
    }
    return String.fromCharCode(...this.data.subarray(start, this.index - 1));
  }
  writeAlphanumeric(contents) {
    if (this.length + 1 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    let index = this.length;
    this._growBy(contents.length);
    const data = this.data;
    let i = 0;
    let code = 0;
    while (i < contents.length) {
      code = data[index++] = contents.charCodeAt(i++);
      if (code > 127)
        throw new Error(`Non-ascii character at char ${i - 1} :${contents}`);
    }
    this.writeByte(0);
  }
  readFloat32() {
    if (this.index + 4 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    uint8Buffer[0] = this.data[this.index++];
    uint8Buffer[1] = this.data[this.index++];
    uint8Buffer[2] = this.data[this.index++];
    uint8Buffer[3] = this.data[this.index++];
    return float32[0];
  }
  readByteArray() {
    let length = this.readVarUint();
    let start = this.index;
    let end = start + length;
    if (end > this.data.length) {
      throw new Error("Read array out of bounds");
    }
    this.index = end;
    let result = new Uint8Array(new ArrayBufferType(length));
    result.set(this.data.subarray(start, end));
    return result;
  }
  readUint32ByteArray() {
    const array = this.readByteArray();
    return new Uint32Array(
      array.buffer,
      0,
      array.length / Uint32Array.BYTES_PER_ELEMENT
    );
  }
  readInt8ByteArray() {
    const array = this.readByteArray();
    return new Int8Array(
      array.buffer,
      0,
      array.length / Int8Array.BYTES_PER_ELEMENT
    );
  }
  readInt16ByteArray() {
    const array = this.readByteArray();
    return new Int16Array(
      array.buffer,
      0,
      array.length / Int16Array.BYTES_PER_ELEMENT
    );
  }
  readInt32ByteArray() {
    const array = this.readByteArray();
    return new Int32Array(
      array.buffer,
      0,
      array.length / Int32Array.BYTES_PER_ELEMENT
    );
  }
  readFloat32ByteArray() {
    const array = this.readByteArray();
    return new Float32Array(
      array.buffer,
      0,
      array.length / Float32Array.BYTES_PER_ELEMENT
    );
  }
  readVarFloat() {
    let index = this.index;
    let data = this.data;
    let length = data.length;
    if (index + 1 > length) {
      throw new Error("Index out of bounds");
    }
    let first = data[index];
    if (first === 0) {
      this.index = index + 1;
      return 0;
    }
    if (index + 4 > length) {
      throw new Error("Index out of bounds");
    }
    let bits = first | data[index + 1] << 8 | data[index + 2] << 16 | data[index + 3] << 24;
    this.index = index + 4;
    bits = bits << 23 | bits >>> 9;
    int32[0] = bits;
    return float32[0];
  }
  readUint32() {
    if (this.index + 4 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    uint8Buffer[0] = this.data[this.index++];
    uint8Buffer[1] = this.data[this.index++];
    uint8Buffer[2] = this.data[this.index++];
    uint8Buffer[3] = this.data[this.index++];
    return uint32[0];
  }
  readUint16() {
    if (this.index + 2 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    uint8Buffer[0] = this.data[this.index++];
    uint8Buffer[1] = this.data[this.index++];
    return uint16[0];
  }
  // This is no longer var uint because the use-case changed and I haven't had time to update all the references
  // This is a uint32 for performance reasons. var uint is very cheap in Go/native languages but very expensive in JavaScript
  // So we opt for the easy route.
  readVarUint() {
    return this.readUint32();
  }
  readInt32() {
    if (this.index + 4 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    uint8Buffer[0] = this.data[this.index++];
    uint8Buffer[1] = this.data[this.index++];
    uint8Buffer[2] = this.data[this.index++];
    uint8Buffer[3] = this.data[this.index++];
    return int32[0];
  }
  readInt16() {
    if (this.index + 2 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    uint8Buffer[0] = this.data[this.index++];
    uint8Buffer[1] = this.data[this.index++];
    return int16[0];
  }
  readInt8() {
    if (this.index + 1 > this.data.length) {
      throw new Error("Index out of bounds");
    }
    uint8Buffer[0] = this.data[this.index++];
    return int8Buffer[0];
  }
  readVarInt() {
    return this.readInt32();
  }
  // This is not a null-terminated string.
  readString() {
    const length = this.readVarUint();
    let start = this.index;
    this.index += length;
    if (!textDecoder) {
      textDecoder = new TextDecoder("utf8");
    }
    return textDecoder.decode(this.data.subarray(start, this.index));
  }
  _growBy(amount) {
    if (this.length + amount > this.data.length) {
      let data = new Uint8Array(
        Math.imul(this.length + amount, _ByteBuffer.WIGGLE_ROOM) << 1
      );
      data.set(this.data);
      this.data = data;
    }
    this.length += amount;
  }
  writeByte(value) {
    let index = this.length;
    this._growBy(1);
    this.data[index] = value;
  }
  writeByteArray(value) {
    this.writeVarUint(value.length);
    let index = this.length;
    this._growBy(value.length);
    this.data.set(value, index);
  }
  writeUint16ByteArray(value) {
    this.writeByteArray(
      new Uint8Array(value.buffer, value.byteOffset, value.byteLength)
    );
  }
  writeUint32ByteArray(value) {
    this.writeByteArray(
      new Uint8Array(value.buffer, value.byteOffset, value.byteLength)
    );
  }
  writeInt8ByteArray(value) {
    this.writeByteArray(
      new Uint8Array(value.buffer, value.byteOffset, value.byteLength)
    );
  }
  writeInt16ByteArray(value) {
    this.writeByteArray(
      new Uint8Array(value.buffer, value.byteOffset, value.byteLength)
    );
  }
  writeInt32ByteArray(value) {
    this.writeByteArray(
      new Uint8Array(value.buffer, value.byteOffset, value.byteLength)
    );
  }
  writeFloat32Array(value) {
    this.writeByteArray(
      new Uint8Array(value.buffer, value.byteOffset, value.byteLength)
    );
  }
  writeVarFloat(value) {
    let index = this.length;
    float32[0] = value;
    let bits = int32[0];
    bits = bits >>> 23 | bits << 9;
    if ((bits & 255) === 0) {
      this.writeByte(0);
      return;
    }
    this._growBy(4);
    let data = this.data;
    data[index] = bits;
    data[index + 1] = bits >> 8;
    data[index + 2] = bits >> 16;
    data[index + 3] = bits >> 24;
  }
  writeFloat32(value) {
    let index = this.length;
    this._growBy(4);
    float32[0] = value;
    this.data.set(uint8Buffer, index);
  }
  writeVarUint(value) {
    this.writeUint32(value);
  }
  writeUint16(value) {
    let index = this.length;
    this._growBy(2);
    uint16[0] = value;
    this.data[index++] = uint8Buffer[0];
    this.data[index++] = uint8Buffer[1];
  }
  writeUint32(value) {
    let index = this.length;
    this._growBy(4);
    uint32[0] = value;
    this.data.set(uint8Buffer, index);
  }
  writeVarInt(value) {
    this.writeInt32(value);
  }
  writeInt8(value) {
    let index = this.length;
    this._growBy(1);
    int8Buffer[0] = value;
    this.data[index++] = uint8Buffer[0];
  }
  writeInt16(value) {
    let index = this.length;
    this._growBy(2);
    int16[0] = value;
    this.data[index++] = uint8Buffer[0];
    this.data[index++] = uint8Buffer[1];
  }
  writeInt32(value) {
    let index = this.length;
    this._growBy(4);
    int32[0] = value;
    this.data.set(uint8Buffer, index);
  }
  writeLowPrecisionFloat(value) {
    this.writeVarInt(Math.round(_ByteBuffer.LOW_PRECISION_VALUE * value));
  }
  readLowPrecisionFloat() {
    return this.readVarInt() / _ByteBuffer.LOW_PRECISION_VALUE;
  }
  writeString(value) {
    var initial_offset = this.length;
    this.writeVarUint(value.length);
    if (!textEncoder) {
      textEncoder = new TextEncoder();
    }
    const offset = this.length;
    this._growBy(value.length * 2 + 5);
    const result = textEncoder.encodeInto(value, this.data.subarray(offset));
    this.length = offset + result.written;
    if (result.written !== value.length) {
      uint32[0] = result.written;
      this.data[initial_offset++] = uint8Buffer[0];
      this.data[initial_offset++] = uint8Buffer[1];
      this.data[initial_offset++] = uint8Buffer[2];
      this.data[initial_offset++] = uint8Buffer[3];
    }
  }
};
var ByteBuffer = _ByteBuffer;
__publicField(ByteBuffer, "WIGGLE_ROOM", 1);
__publicField(ByteBuffer, "LOW_PRECISION_VALUE", 10 ** 3);

// util.ts
function quote(text) {
  return JSON.stringify(text);
}
function error(text, line, column) {
  var error2 = new Error(text);
  error2.line = line;
  error2.column = column;
  throw error2;
}

// parser.ts
var nativeTypes = [
  "bool",
  "byte",
  "float",
  "int",
  "uint8",
  "uint16",
  "uint32",
  "int8",
  "int16",
  "lowp",
  "int32",
  "float32",
  "string",
  "uint",
  "discriminator",
  "alphanumeric"
];
var nativeTypeMap = {
  bool: 1,
  byte: 1,
  float: 1,
  int: 1,
  uint8: 1,
  uint16: 1,
  uint32: 1,
  int8: 1,
  int16: 1,
  int32: 1,
  float32: 1,
  string: 1,
  uint: 1,
  discriminator: 1,
  alphanumeric: 1
};
var reservedNames = ["ByteBuffer", "package", "Allocator"];
var regex = /((?:-|\b)\d+\b|[=\:;{}]|\[\]|\[deprecated\]|\[!\]|\b[A-Za-z_][A-Za-z0-9_]*\b|"|-|\&|\||\/\/.*|\s+)/g;
var identifier = /^[A-Za-z_][A-Za-z0-9_]*$/;
var whitespace = /^\/\/.*|\s+$/;
var equals = /^=$/;
var endOfFile = /^$/;
var semicolon = /^;$/;
var integer = /^-?\d+$/;
var leftBrace = /^\{$/;
var rightBrace = /^\}$/;
var arrayToken = /^\[\]$/;
var enumKeyword = /^enum$/;
var smolKeyword = /^smol$/;
var quoteToken = /^"$/;
var serializerKeyword = /^from$/;
var colon = /^:$/;
var packageKeyword = /^package$/;
var pick = /^pick$/;
var entityKeyword = /^entity$/;
var structKeyword = /^struct$/;
var aliasKeyword = /^alias$/;
var unionKeyword = /^union$/;
var messageKeyword = /^message$/;
var deprecatedToken = /^\[deprecated\]$/;
var unionOrToken = /^\|$/;
var extendsToken = /^&$/;
var requiredToken = /^\[!\]$/;
function tokenize(text) {
  let parts = text.split(regex);
  let tokens = [];
  let column = 0;
  let line = 0;
  for (let i = 0; i < parts.length; i++) {
    let part = parts[i];
    if (i & 1) {
      if (!whitespace.test(part)) {
        tokens.push({
          text: part,
          line: line + 1,
          column: column + 1
        });
      }
    } else if (part !== "") {
      error("Syntax error " + quote(part), line + 1, column + 1);
    }
    let lines = part.split("\n");
    if (lines.length > 1)
      column = 0;
    line += lines.length - 1;
    column += lines[lines.length - 1].length;
  }
  tokens.push({
    text: "",
    line,
    column
  });
  return tokens;
}
function parse(tokens) {
  function current() {
    return tokens[index];
  }
  function eat(test) {
    if (test.test(current().text)) {
      index++;
      return true;
    }
    return false;
  }
  function expect(test, expected) {
    if (!eat(test)) {
      let token = current();
      error(
        "Expected " + expected + " but found " + quote(token.text),
        token.line,
        token.column
      );
    }
  }
  function unexpectedToken() {
    let token = current();
    error("Unexpected token " + quote(token.text), token.line, token.column);
  }
  let definitions = [];
  let packageText = null;
  let index = 0;
  let picks = {};
  if (eat(packageKeyword)) {
    packageText = current().text;
    expect(identifier, "identifier");
    expect(semicolon, '";"');
  }
  let serializerPath;
  while (index < tokens.length && !eat(endOfFile)) {
    let fields = [];
    let extensions;
    let kind;
    if (eat(enumKeyword))
      kind = "ENUM";
    else if (eat(smolKeyword))
      kind = "SMOL";
    else if (eat(pick))
      kind = "PICK";
    else if (eat(structKeyword))
      kind = "STRUCT";
    else if (eat(messageKeyword))
      kind = "MESSAGE";
    else if (eat(entityKeyword))
      kind = "ENTITY";
    else if (eat(unionKeyword))
      kind = "UNION";
    else if (eat(aliasKeyword))
      kind = "ALIAS";
    else
      unexpectedToken();
    let name = current();
    expect(identifier, "identifier");
    if (kind === "PICK") {
      expect(colon, '":"');
      let field = current();
      expect(identifier, "identifier");
      expect(leftBrace, '"{"');
      const fieldNames = [];
      picks[name.text] = {
        to: name,
        fieldNames,
        from: field
      };
      while (!eat(rightBrace)) {
        field = current();
        expect(identifier, "identifier");
        if (fieldNames.includes(field.text)) {
          error("Fields must be unique", field.line, field.column);
        }
        fieldNames.push(field.text);
        expect(semicolon, ";");
      }
      continue;
    } else if (kind === "UNION") {
      expect(equals, '"="');
      let field = current();
      expect(identifier, "identifier");
      fields.push({
        name: field.text,
        line: field.line,
        column: field.column,
        type: field.text,
        isArray: false,
        isRequired: true,
        isDeprecated: false,
        value: fields.length + 1
      });
      while (eat(unionOrToken)) {
        field = current();
        expect(identifier, "identifier");
        fields.push({
          name: field.text,
          line: field.line,
          column: field.column,
          type: field.text,
          isArray: false,
          isDeprecated: false,
          isRequired: true,
          value: fields.length + 1
        });
      }
      if (eat(leftBrace)) {
        field = current();
        expect(identifier, "discriminator name");
        fields.unshift({
          type: "discriminator",
          name: field.text,
          line: field.line,
          column: field.column,
          isArray: false,
          isDeprecated: false,
          isRequired: true,
          value: 0
        });
        expect(semicolon, ";");
        expect(rightBrace, "}");
      } else {
        expect(semicolon, '";"');
      }
    } else if (kind === "ALIAS") {
      expect(equals, "=");
      let field = current();
      expect(identifier, "identifier");
      fields.push({
        type: field.text,
        name: field.text,
        line: field.line,
        column: field.column,
        isArray: false,
        isDeprecated: false,
        isRequired: true,
        value: 1
      });
      expect(semicolon, ";");
    } else {
      if (kind === "STRUCT") {
        while (eat(extendsToken)) {
          let field = current();
          expect(identifier, "discriminator name");
          if (!extensions) {
            extensions = [field.text];
          } else {
            extensions.push(field.text);
          }
        }
      }
      if (eat(serializerKeyword)) {
        expect(quoteToken, '"');
        serializerPath = "";
        while (!eat(quoteToken)) {
          serializerPath += current().text;
          index++;
        }
      }
      expect(leftBrace, '"{"');
      while (!eat(rightBrace)) {
        let type = null;
        let isArray = false;
        let isDeprecated = false;
        if (kind !== "ENUM" && kind !== "SMOL") {
          type = current().text;
          expect(identifier, "identifier");
          isArray = eat(arrayToken);
        }
        let field = current();
        expect(identifier, "identifier");
        let value = null;
        let isRequired = kind === "STRUCT";
        if (kind !== "STRUCT") {
          expect(equals, '"="');
          value = current();
          expect(integer, "integer");
          if (eat(requiredToken)) {
            isRequired = true;
          }
          if ((+value.text | 0) + "" !== value.text) {
            error(
              "Invalid integer " + quote(value.text),
              value.line,
              value.column
            );
          }
        }
        let deprecated = current();
        if (eat(deprecatedToken)) {
          if (kind !== "MESSAGE") {
            error(
              "Cannot deprecate this field",
              deprecated.line,
              deprecated.column
            );
          }
          isDeprecated = true;
        }
        expect(semicolon, '";"');
        fields.push({
          name: field.text,
          line: field.line,
          column: field.column,
          type,
          isArray,
          isDeprecated,
          isRequired,
          value: value !== null ? +value.text | 0 : fields.length + 1
        });
      }
    }
    definitions.push({
      name: name.text,
      line: name.line,
      column: name.column,
      kind,
      fields,
      extensions,
      serializerPath: serializerPath && serializerPath.trim().length > 0 ? serializerPath : void 0
    });
    serializerPath = "";
  }
  for (let definition of definitions) {
    if (definition.extensions) {
      for (let extension of definition.extensions) {
        let otherDefinition = definition;
        for (let i = 0; i < definitions.length; i++) {
          otherDefinition = definitions[i];
          if (extension === otherDefinition.name) {
            break;
          }
        }
        if (otherDefinition.name !== extension || otherDefinition.kind !== "STRUCT") {
          error(
            `Expected ${otherDefinition.name} to to be a struct`,
            definition.line,
            definition.column
          );
        }
        let offset = definition.fields.length;
        for (let field of otherDefinition.fields) {
          definition.fields.push({
            ...field,
            value: field.value + offset
          });
        }
      }
    }
  }
  let foundMatch = false;
  for (let partName in picks) {
    const pick2 = picks[partName];
    const token = pick2.from;
    let definition = definitions[0];
    for (let i = 0; i < definitions.length; i++) {
      definition = definitions[i];
      if (definition.name === token.text) {
        foundMatch = true;
        break;
      }
    }
    if (!foundMatch) {
      error("Expected type for part to exist", token.line, token.column);
    }
    foundMatch = false;
    const fields = new Array(pick2.fieldNames.length);
    let field = definition.fields[0];
    for (let i = 0; i < fields.length; i++) {
      let name = pick2.fieldNames[i];
      foundMatch = false;
      field = definition.fields[0];
      for (let j = 0; j < definition.fields.length; j++) {
        if (definition.fields[j].name === name) {
          field = definition.fields[j];
          foundMatch = true;
        }
      }
      if (!foundMatch) {
        error(
          `Expected field ${name} to exist in ${definition.name}`,
          token.line,
          token.column
        );
      }
      fields[i] = {
        name: field.name,
        line: field.line,
        column: field.column,
        type: field.type,
        isRequired: true,
        isArray: field.isArray,
        isDeprecated: field.isDeprecated,
        value: i + 1
      };
    }
    definitions.push({
      name: pick2.to.text,
      line: token.line,
      column: token.column,
      kind: "STRUCT",
      fields
    });
  }
  return {
    package: packageText,
    definitions
  };
}
function verify(root) {
  let definedTypes = nativeTypes.slice();
  let definitions = {};
  for (let i = 0; i < root.definitions.length; i++) {
    let definition = root.definitions[i];
    if (definedTypes.indexOf(definition.name) !== -1) {
      error(
        "The type " + quote(definition.name) + " is defined twice",
        definition.line,
        definition.column
      );
    }
    if (reservedNames.indexOf(definition.name) !== -1) {
      error(
        "The type name " + quote(definition.name) + " is reserved",
        definition.line,
        definition.column
      );
    }
    definedTypes.push(definition.name);
    definitions[definition.name] = definition;
  }
  for (let i = 0; i < root.definitions.length; i++) {
    let definition = root.definitions[i];
    let fields = definition.fields;
    if (definition.kind === "ENUM" || definition.kind === "SMOL" || fields.length === 0) {
      continue;
    }
    if (definition.kind === "UNION") {
      let state2 = {};
      for (let j = 0; j < fields.length; j++) {
        let field = fields[j];
        if (state2[field.name]) {
          error(
            "The type " + quote(field.type) + " can only appear in  " + quote(definition.name) + " once.",
            field.line,
            field.column
          );
        }
        state2[field.name] = 1;
        if (definedTypes.indexOf(field.type) === -1) {
          error(
            "The type " + quote(field.type) + " is not defined for union " + quote(definition.name),
            field.line,
            field.column
          );
        }
      }
    } else if (definition.kind === "ALIAS") {
      const field = definition.fields[0];
      if (!field)
        error("Expected alias name", definition.line, definition.column);
      if (!(definitions[field.name] || nativeTypeMap[field.name])) {
        error(
          "Expected type used in alias to exist.",
          definition.line,
          definition.column
        );
      }
    } else {
      for (let j = 0; j < fields.length; j++) {
        let field = fields[j];
        if (definedTypes.indexOf(field.type) === -1) {
          error(
            "The type " + quote(field.type) + " is not defined for field " + quote(field.name),
            field.line,
            field.column
          );
        }
        if (field.type === "discriminator") {
          error(
            "discriminator is only available inside of unions.",
            field.line,
            field.column
          );
        }
      }
    }
    let values = [];
    for (let j = 0; j < fields.length; j++) {
      let field = fields[j];
      if (values.indexOf(field.value) !== -1) {
        error(
          "The id for field " + quote(field.name) + " is used twice",
          field.line,
          field.column
        );
      }
      if (field.value <= 0 && field.type !== "discriminator") {
        error(
          "The id for field " + quote(field.name) + " must be positive",
          field.line,
          field.column
        );
      }
      if (field.value > fields.length) {
        error(
          "The id for field " + quote(field.name) + " cannot be larger than " + fields.length,
          field.line,
          field.column
        );
      }
      values.push(field.value);
    }
  }
  let state = {};
  let check = (name) => {
    let definition = definitions[name];
    if (definition && definition.kind === "STRUCT") {
      if (state[name] === 1) {
        error(
          "Recursive nesting of " + quote(name) + " is not allowed",
          definition.line,
          definition.column
        );
      }
      if (state[name] !== 2 && definition) {
        state[name] = 1;
        let fields = definition.fields;
        for (let i = 0; i < fields.length; i++) {
          let field = fields[i];
          if (!field.isArray) {
            check(field.type);
          }
        }
        state[name] = 2;
      }
    }
    return true;
  };
  for (let i = 0; i < root.definitions.length; i++) {
    check(root.definitions[i].name);
  }
}
function parseSchema(text) {
  const schema = parse(tokenize(text));
  verify(schema);
  return schema;
}

// js.ts
function isDiscriminatedUnion(name, definitions) {
  if (!definitions[name])
    return false;
  if (!definitions[name].fields.length)
    return false;
  return definitions[name].fields[0].type === "discriminator";
}
function compileDecode(functionName, definition, definitions, withAllocator = false, aliases) {
  let lines = [];
  let indent = "  ";
  if (definition.kind === "UNION") {
    const hasDiscriminator = isDiscriminatedUnion(definition.name, definitions);
    if (hasDiscriminator) {
      lines.push(`function ${functionName}(bb) {`);
    } else {
      lines.push(`function ${functionName}(bb, type = 0) {`);
    }
    lines.push("");
    if (hasDiscriminator) {
      lines.push("  switch (bb.readByte()) {");
      indent = "      ";
      for (let i = 1; i < definition.fields.length; i++) {
        let field = definition.fields[i];
        lines.push(
          `    case ${field.value}:`,
          indent + "var result = " + ("decode" + field.name) + "(bb);",
          indent + `result[${quote(definition.fields[0].name)}] = ${field.value};`,
          indent + `return result;`
        );
      }
    } else {
      lines.push("  switch (type) {");
      indent = "      ";
      for (let i = 0; i < definition.fields.length; i++) {
        let field = definition.fields[i];
        lines.push(
          `    case ${field.value}:`,
          indent + `return ${"decode" + field.name}(bb)`
        );
      }
    }
  } else {
    lines.push(`function ${functionName}(bb) {`);
    if (!withAllocator) {
      lines.push("  var result = {};");
    } else {
      lines.push(
        "  var result = Allocator[" + quote(definition.name) + "].alloc();"
      );
    }
    lines.push("");
    if (definition.kind === "MESSAGE") {
      lines.push("  while (true) {");
      lines.push("    switch (bb.readByte()) {");
      lines.push("    case 0:");
      lines.push("      return result;");
      lines.push("");
      indent = "      ";
    }
    for (let i = 0; i < definition.fields.length; i++) {
      let field = definition.fields[i];
      let code;
      let fieldType = field.type;
      if (aliases[fieldType])
        fieldType = aliases[fieldType];
      switch (fieldType) {
        case "bool": {
          code = "!!bb.readByte()";
          break;
        }
        case "uint8":
        case "byte": {
          code = "bb.readByte()";
          break;
        }
        case "int16": {
          code = "bb.readInt16()";
          break;
        }
        case "alphanumeric": {
          code = "bb.readAlphanumeric()";
          break;
        }
        case "int8": {
          code = "bb.readInt8()";
          break;
        }
        case "int32": {
          code = "bb.readInt32()";
          break;
        }
        case "int": {
          code = "bb.readVarInt()";
          break;
        }
        case "uint16": {
          code = "bb.readUint16()";
          break;
        }
        case "uint32": {
          code = "bb.readUint32()";
          break;
        }
        case "lowp": {
          code = "bb.readLowPrecisionFloat()";
          break;
        }
        case "uint": {
          code = "bb.readVarUint()";
          break;
        }
        case "float": {
          code = "bb.readVarFloat()";
          break;
        }
        case "float32": {
          code = "bb.readFloat32()";
          break;
        }
        case "string": {
          code = "bb.readString()";
          break;
        }
        default: {
          let type = definitions[fieldType];
          if (!type) {
            error(
              "Invalid type " + quote(fieldType) + " for field " + quote(field.name),
              field.line,
              field.column
            );
          } else if (type.kind === "ENUM") {
            code = type.name + "[bb.readVarUint()]";
          } else if (type.kind === "SMOL") {
            code = type.name + "[bb.readByte()]";
          } else {
            code = "decode" + type.name + "(bb)";
          }
        }
      }
      if (definition.kind === "MESSAGE") {
        lines.push("    case " + field.value + ":");
      }
      if (field.isArray) {
        if (field.isDeprecated) {
          if (fieldType === "byte") {
            lines.push(indent + "bb.readByteArray();");
          } else {
            lines.push(indent + "var length = bb.readVarUint();");
            lines.push(indent + "while (length-- > 0) " + code + ";");
          }
        } else {
          switch (fieldType) {
            case "byte": {
              lines.push(
                indent + "result[" + quote(field.name) + "] = bb.readByteArray();"
              );
              break;
            }
            case "uint16": {
              lines.push(
                indent + "result[" + quote(field.name) + "] = bb.readUint16ByteArray();"
              );
              break;
            }
            case "uint32": {
              lines.push(
                indent + "result[" + quote(field.name) + "] = bb.readUint32ByteArray();"
              );
              break;
            }
            case "int8": {
              lines.push(
                indent + "result[" + quote(field.name) + "] = bb.readInt8ByteArray();"
              );
              break;
            }
            case "int16": {
              lines.push(
                indent + "result[" + quote(field.name) + "] = bb.readInt16ByteArray();"
              );
              break;
            }
            case "int32": {
              lines.push(
                indent + "result[" + quote(field.name) + "] = bb.readInt32ByteArray();"
              );
              break;
            }
            case "float32": {
              lines.push(
                indent + "result[" + quote(field.name) + "] = bb.readFloat32ByteArray();"
              );
              break;
            }
            default: {
              lines.push(indent + "var length = bb.readVarUint();");
              lines.push(
                indent + "var values = result[" + quote(field.name) + "] = Array(length);"
              );
              lines.push(
                indent + "for (var i = 0; i < length; i++) values[i] = " + code + ";"
              );
              break;
            }
          }
        }
      } else if (fieldType && isDiscriminatedUnion(fieldType, definitions)) {
        lines.push(
          indent + "result[" + quote(field.name) + `] = ${"decode" + fieldType}(bb);`
        );
      } else if (fieldType && definitions[fieldType] && definitions[fieldType].kind === "UNION") {
        const key = quote(field.name + "Type");
        lines.push(
          indent + "result[" + key + "] = bb.readVarUint();",
          indent + "result[" + quote(field.name) + `] = ${"decode" + fieldType}(bb, result[${key}]);`
        );
      } else {
        if (field.isDeprecated) {
          lines.push(indent + code + ";");
        } else {
          lines.push(
            indent + "result[" + quote(field.name) + "] = " + code + ";"
          );
        }
      }
      if (definition.kind === "MESSAGE") {
        lines.push("      break;");
        lines.push("");
      }
    }
  }
  if (definition.kind === "MESSAGE") {
    lines.push("    default:");
    lines.push('      throw new Error("Attempted to parse invalid message");');
    lines.push("    }");
    lines.push("  }");
  } else if (definition.kind === "UNION") {
    lines.push("    default:");
    lines.push(`      throw new Error("Attempted to parse invalid union");`);
    lines.push("  }");
  } else {
    lines.push("  return result;");
  }
  lines.push("}");
  return lines.join("\n");
}
function compileEncode(functionName, definition, definitions, aliases) {
  let lines = [];
  if (definition.kind === "UNION") {
    const discriminator = definition.fields[0];
    const hasDiscriminator = discriminator.type === "discriminator";
    lines.push(`function ${functionName}(message, bb, type = 0) {`);
    if (hasDiscriminator) {
      lines.push(
        `  type = type ? type : ${definition.name}[message[${quote(
          discriminator.name
        )}]];`
      );
      lines.push(
        `  if (!type) throw new Error('Expected message[${quote(
          discriminator.name
        )}] to be one of ' + JSON.stringify(${definition.name}) + ' ');`
      );
    } else {
      lines.push(
        `  if (!type) throw new Error('Expected type to be one of ' + JSON.stringify(${definition.name}, null, 2) + ' ');`
      );
    }
    lines.push("");
    lines.push(`  bb.writeByte(type);`);
    lines.push("");
    lines.push(`  switch (type) {`);
    for (let j = hasDiscriminator ? 1 : 0; j < definition.fields.length; j++) {
      let field = definition.fields[j];
      let code;
      if (field.isDeprecated) {
        continue;
      }
      lines.push(`    case ${field.value}: {`);
      lines.push(`      ${"encode" + field.name}(message, bb)`);
      lines.push(`      break;`);
      lines.push(`    }`);
    }
    lines.push(`    default: {`);
    lines.push(
      `      throw new Error('Expected message[${quote(
        discriminator.name
      )}] to be one of ' + JSON.stringify(${definition.name}) + ' ');`
    );
    lines.push(`    }`);
    lines.push(`  }`);
    lines.push("");
    lines.push("}");
    return lines.join("\n");
  } else {
    lines.push(`function ${functionName}(message, bb) {`);
  }
  for (let j = 0; j < definition.fields.length; j++) {
    let field = definition.fields[j];
    let code;
    if (field.isDeprecated) {
      continue;
    }
    let fieldType = field.type;
    if (aliases[fieldType])
      fieldType = aliases[fieldType];
    switch (fieldType) {
      case "bool": {
        code = "bb.writeByte(value);";
        break;
      }
      case "byte": {
        code = "bb.writeByte(value);";
        break;
      }
      case "alphanumeric": {
        code = "bb.writeAlphanumeric(value);";
        break;
      }
      case "int": {
        code = "bb.writeVarInt(value);";
        break;
      }
      case "int8": {
        code = "bb.writeInt8(value);";
        break;
      }
      case "int16": {
        code = "bb.writeInt16(value);";
        break;
      }
      case "int32": {
        code = "bb.writeInt32(value);";
        break;
      }
      case "uint": {
        code = "bb.writeVarUint(value);";
        break;
      }
      case "lowp": {
        code = "bb.writeLowPrecisionFloat(value);";
        break;
      }
      case "uint8": {
        code = "bb.writeByte(value);";
        break;
      }
      case "uint16": {
        code = "bb.writeUint16(value);";
        break;
      }
      case "uint32": {
        code = "bb.writeUint32(value);";
        break;
      }
      case "float": {
        code = "bb.writeVarFloat(value);";
        break;
      }
      case "float32": {
        code = "bb.writeFloat32(value);";
        break;
      }
      case "string": {
        code = "bb.writeString(value);";
        break;
      }
      case "discriminator": {
        code = `bb.writeVarUint(type);`;
        break;
      }
      default: {
        let type = definitions[fieldType];
        if (!type) {
          throw new Error(
            "Invalid type " + quote(fieldType) + " for field " + quote(field.name)
          );
        } else if (type.kind === "ENUM") {
          code = "var encoded = " + type.name + '[value];\nif (encoded === void 0) throw new Error("Invalid value " + JSON.stringify(value) + ' + quote(" for enum " + quote(type.name)) + ");\nbb.writeVarUint(encoded);";
        } else if (type.kind === "SMOL") {
          code = "var encoded = " + type.name + '[value];\nif (encoded === void 0) throw new Error("Invalid value " + JSON.stringify(value) + ' + quote(" for enum " + quote(type.name)) + ");\nbb.writeByte(encoded);";
        } else if (type.kind === "UNION" && isDiscriminatedUnion(type.name, definitions)) {
          code = "encode" + type.name + "(value, bb);";
        } else if (type.kind === "UNION") {
          code = "var encoded = " + type.name + `[message[${quote(field.name + "Type")}]];
    if (encoded === void 0) throw new Error('Expected ${quote(
            field.name + "Type"
          )} to be one of ' + JSON.stringify(${type.name},null,2) + ' for enum ${quote(type.name)}');`;
          code += "encode" + type.name + "(value, bb, encoded);";
        } else {
          code = "encode" + type.name + "(value, bb);";
        }
      }
    }
    lines.push("");
    if (fieldType === "discriminator") {
      error("Unexpected discriminator", field.line, field.column);
    } else {
      lines.push("  var value = message[" + quote(field.name) + "];");
      lines.push("  if (value != null) {");
    }
    if (definition.kind === "MESSAGE") {
      lines.push("    bb.writeByte(" + field.value + ");");
    }
    if (field.isArray) {
      let indent = "   ";
      switch (fieldType) {
        case "byte": {
          lines.push(indent + "bb.writeByteArray(value);");
          break;
        }
        case "uint16": {
          lines.push(indent + "bb.writeUint16ByteArray(value);");
          break;
        }
        case "uint32": {
          lines.push(indent + "bb.writeUint32ByteArray(value);");
          break;
        }
        case "int8": {
          lines.push(indent + "bb.writeInt8ByteArray(value);");
          break;
        }
        case "int16": {
          lines.push(indent + "bb.writeInt16ByteArray(value);");
          break;
        }
        case "int32": {
          lines.push(indent + "bb.writeInt32ByteArray(value);");
          break;
        }
        case "float32": {
          lines.push(indent + "bb.writeFloat32ByteArray(value);");
          break;
        }
        default: {
          lines.push("    var values = value, n = values.length;");
          lines.push("    bb.writeVarUint(n);");
          lines.push("    for (var i = 0; i < n; i++) {");
          lines.push("      value = values[i];");
          lines.push("      " + code);
          lines.push("    }");
        }
      }
    } else {
      lines.push("    " + code);
    }
    if (definition.kind === "STRUCT") {
      lines.push("  } else {");
      lines.push(
        "    throw new Error(" + quote("Missing required field " + quote(field.name)) + ");"
      );
    }
    lines.push("  }");
  }
  if (definition.kind === "MESSAGE") {
    lines.push("  bb.writeByte(0);");
  }
  lines.push("");
  lines.push("}");
  return lines.join("\n");
}
function compileSchemaJS(schema, isESM = false, withAllocator = false) {
  var _a, _b;
  let definitions = {};
  let aliases = {};
  let name = schema.package;
  let js = [];
  const exportsList = [];
  const importsList = [];
  if (isESM) {
    name = "exports";
  } else {
    if (name !== null) {
      js.push("var " + name + " = exports || " + name + " || {}, exports;");
    } else {
      js.push("var exports = exports || {};");
      name = "exports";
    }
  }
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    definitions[definition.name] = definition;
    if (definition.kind === "ALIAS") {
      aliases[definition.name] = definition.fields[0].name;
    }
    if (isESM && ((_a = definition.serializerPath) == null ? void 0 : _a.length)) {
      importsList.push(
        `import {encode${definition.name}, decode${definition.name}} from "${definition.serializerPath}";`
      );
    }
  }
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    if (definition.kind === "ALIAS")
      continue;
    switch (definition.kind) {
      case "SMOL":
      case "ENUM": {
        let value = {};
        let keys = {};
        for (let j = 0; j < definition.fields.length; j++) {
          let field = definition.fields[j];
          value[field.name] = field.value;
          value[field.value] = field.value;
          keys[field.name] = field.name;
          keys[field.value] = field.name;
        }
        exportsList.push(definition.name, definition.name + "Keys");
        js.push(
          "const " + definition.name + " = " + JSON.stringify(value, null, 2) + ";"
        );
        js.push(
          "const " + definition.name + "Keys = " + JSON.stringify(keys, null, 2) + ";"
        );
        break;
      }
      case "UNION": {
        let value = {};
        let keys = {};
        const encoders = new Array(definition.fields.length);
        encoders.fill("() => null");
        for (let j = 0; j < definition.fields.length; j++) {
          let field = definition.fields[j];
          let fieldType = field.type;
          if (field.value > 0) {
            if (aliases[field.name])
              field.name = aliases[field.name];
            value[field.name] = field.value;
            value[field.value] = field.value;
            keys[field.name] = field.name;
            keys[field.value] = field.name;
            encoders[field.value] = "encode" + fieldType;
          }
        }
        exportsList.push(definition.name);
        js.push(
          "const " + definition.name + " = " + JSON.stringify(value, null, 2) + ";"
        );
        js.push(
          "const " + definition.name + "Keys = " + JSON.stringify(keys, null, 2) + ";"
        );
        exportsList.push(`${definition.name}Keys`);
        js.push("const " + definition.name + "Type = " + definition.name + ";");
        exportsList.push(definition.name + "Type");
        const encoderName = encoders.join(" , ");
        js.push(
          "const encode" + definition.name + "ByType = (function() { return [" + encoderName + "]; })()"
        );
      }
      case "STRUCT":
      case "MESSAGE": {
        exportsList.push(
          "decode" + definition.name,
          "encode" + definition.name
        );
        if (!isESM || !((_b = definition.serializerPath) == null ? void 0 : _b.length)) {
          js.push("");
          js.push(
            compileDecode(
              "decode" + definition.name,
              definition,
              definitions,
              withAllocator,
              aliases
            )
          );
          js.push("");
          js.push(
            compileEncode(
              "encode" + definition.name,
              definition,
              definitions,
              aliases
            )
          );
        }
        break;
      }
      default: {
        error(
          "Invalid definition kind " + quote(definition.kind),
          definition.line,
          definition.column
        );
        break;
      }
    }
  }
  js.push("");
  if (isESM) {
    for (let importName of importsList) {
      js.unshift(importName);
    }
    for (let exportName of exportsList) {
      js.push(`export { ${exportName} }`);
    }
  } else {
    for (let exportName of exportsList) {
      js.push(`exports[${quote(exportName)}] = ${exportName};`);
    }
  }
  return js.join("\n");
}
function compileSchema(schema, useESM = false, Allocator) {
  let result = Allocator ? {
    Allocator,
    ByteBuffer
  } : { ByteBuffer };
  if (typeof schema === "string") {
    schema = parseSchema(schema);
  }
  let out = compileSchemaJS(schema, useESM, !!Allocator);
  if (useESM) {
    if (Allocator) {
      out = `import * as Allocator from "${Allocator}";

${out}`;
    }
    return out;
  } else {
    new Function("exports", out)(result);
    return result;
  }
}

// cpp-callback.ts
function argumentForField(definitions, type, name) {
  switch (type) {
    case "bool":
      return { type: "bool ", name };
    case "byte":
      return { type: "uint8_t ", name };
    case "int":
      return { type: "int32_t ", name };
    case "uint":
      return { type: "uint32_t ", name };
    case "float":
      return { type: "float ", name };
    case "string":
      return { type: "const char *", name };
    default: {
      let definition = definitions[type];
      if (definition.kind === "ENUM")
        return { type: definition.name + " ", name };
      return null;
    }
  }
}
function extractStructArguments(definitions, prefix, fields, allowArrays) {
  let args = [];
  for (let i = 0; i < fields.length; i++) {
    let field = fields[i];
    let name = prefix + field.name;
    if (field.isArray && !allowArrays) {
      return null;
    }
    let arg = argumentForField(definitions, field.type, name);
    if (arg !== null) {
      args.push(arg);
      continue;
    }
    let type = definitions[field.type];
    if (type.kind !== "STRUCT") {
      return null;
    }
    let typeArgs = extractStructArguments(definitions, name + "_", type.fields, false);
    if (typeArgs === null) {
      return null;
    }
    args.push.apply(args, typeArgs);
  }
  return args;
}
function argToDeclaration(arg) {
  return arg.type + arg.name;
}
function argToName(arg) {
  return arg.name;
}
function argToNotRead(arg) {
  switch (arg.type) {
    case "bool ":
    case "uint8_t ":
      return "!bb.readByte(" + arg.name + ")";
    case "int32_t ":
      return "!bb.readVarInt(" + arg.name + ")";
    case "uint32_t ":
      return "!bb.readVarUint(" + arg.name + ")";
    case "float ":
      return "!bb.readVarFloat(" + arg.name + ")";
    case "const char *":
      return "!bb.readString(" + arg.name + ")";
    default:
      return "!bb.readVarUint(reinterpret_cast<uint32_t &>(" + arg.name + "))";
  }
}
function argToWrite(arg) {
  switch (arg.type) {
    case "bool ":
    case "uint8_t ":
      return "_bb.writeByte(" + arg.name + ")";
    case "int32_t ":
      return "_bb.writeVarInt(" + arg.name + ")";
    case "uint32_t ":
      return "_bb.writeVarUint(" + arg.name + ")";
    case "float ":
      return "_bb.writeVarFloat(" + arg.name + ")";
    case "const char *":
      return "_bb.writeString(" + arg.name + ")";
    default:
      return "_bb.writeVarUint(static_cast<uint32_t>(" + arg.name + "))";
  }
}
function emitReadField(cpp, definitions, definition, field, indent) {
  let name = field.name;
  if (field.isArray) {
    let count = "_" + name + "_count";
    cpp.push(indent + "uint32_t " + count + ";");
    cpp.push(indent + "if (!bb.readVarUint(" + count + ")) return false;");
    if (!field.isDeprecated) {
      cpp.push(indent + "visitor.visit" + definition.name + "_" + field.name + "_count(" + count + ");");
    }
    cpp.push(indent + "while (" + count + "-- > 0) {");
    indent += "  ";
    name += "_element";
  }
  let args = extractStructArguments(definitions, "", [field], true);
  if (args !== null) {
    for (let i = 0; i < args.length; i++) {
      cpp.push(indent + argToDeclaration(args[i]) + ";");
    }
    cpp.push(indent + "if (" + args.map(argToNotRead).join(" || ") + ") return false;");
    if (!field.isDeprecated) {
      cpp.push(indent + "visitor.visit" + definition.name + "_" + name + "(" + args.map(argToName).join(", ") + ");");
    }
  } else {
    if (!field.isDeprecated) {
      cpp.push(indent + "visitor.visit" + definition.name + "_" + name + "();");
    }
    let type = definitions[field.type];
    cpp.push(indent + "if (!parse" + type.name + "(bb, visitor)) return false;");
  }
  if (field.isArray) {
    cpp.push(indent.slice(2) + "}");
  }
}
function compileSchemaCallbackCPP(schema) {
  let definitions = {};
  let cpp = [];
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    definitions[definition.name] = definition;
  }
  if (schema.package !== null) {
    cpp.push("#ifndef INCLUDE_" + schema.package.toUpperCase() + "_H");
    cpp.push("#define INCLUDE_" + schema.package.toUpperCase() + "_H");
    cpp.push("");
  }
  cpp.push('#include "kiwi.h"');
  cpp.push("");
  if (schema.package !== null) {
    cpp.push("namespace " + schema.package + " {");
    cpp.push("");
  }
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    if (definition.kind === "ENUM") {
      cpp.push("enum class " + definition.name + " : uint32_t {");
      for (let j = 0; j < definition.fields.length; j++) {
        let field = definition.fields[j];
        if (!field.isDeprecated) {
          cpp.push("  " + field.name + " = " + field.value + ",");
        }
      }
      cpp.push("};");
      cpp.push("");
    }
  }
  for (let pass = 0; pass < 2; pass++) {
    let suffix = ") = 0;";
    if (pass === 0) {
      cpp.push("class Visitor {");
      cpp.push("public:");
    } else {
      cpp.push("class Writer : public Visitor {");
      cpp.push("private:");
      cpp.push("  kiwi::ByteBuffer &_bb;");
      cpp.push("public:");
      cpp.push("  Writer(kiwi::ByteBuffer &bb) : _bb(bb) {}");
      suffix = ") override;";
    }
    for (let i = 0; i < schema.definitions.length; i++) {
      let definition = schema.definitions[i];
      if (definition.kind === "STRUCT") {
        let args = extractStructArguments(definitions, "", definition.fields, false);
        if (args !== null) {
          cpp.push("  virtual void visit" + definition.name + "(" + args.map(argToDeclaration).join(", ") + suffix);
          continue;
        }
      }
      if (definition.kind === "STRUCT" || definition.kind === "MESSAGE") {
        cpp.push("  virtual void begin" + definition.name + "(" + suffix);
        for (let j = 0; j < definition.fields.length; j++) {
          let field = definition.fields[j];
          if (field.isDeprecated) {
            continue;
          }
          let name = field.name;
          if (field.isArray) {
            cpp.push("  virtual void visit" + definition.name + "_" + field.name + "_count(uint32_t size" + suffix);
            name += "_element";
          }
          let args = extractStructArguments(definitions, "", [field], true);
          if (args !== null) {
            cpp.push("  virtual void visit" + definition.name + "_" + name + "(" + args.map(argToDeclaration).join(", ") + suffix);
          } else {
            cpp.push("  virtual void visit" + definition.name + "_" + name + "(" + suffix);
          }
        }
        cpp.push("  virtual void end" + definition.name + "(" + suffix);
      }
    }
    cpp.push("};");
    cpp.push("");
  }
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    if (definition.kind === "STRUCT" || definition.kind === "MESSAGE") {
      cpp.push("bool parse" + definition.name + "(kiwi::ByteBuffer &bb, Visitor &visitor);");
    }
  }
  cpp.push("");
  cpp.push("#ifdef IMPLEMENT_SCHEMA_H");
  cpp.push("");
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    if (definition.kind === "STRUCT") {
      let args = extractStructArguments(definitions, "", definition.fields, false);
      if (args !== null) {
        cpp.push("bool parse" + definition.name + "(kiwi::ByteBuffer &bb, Visitor &visitor) {");
        for (let j = 0; j < args.length; j++) {
          cpp.push("  " + argToDeclaration(args[j]) + ";");
        }
        cpp.push("  if (" + args.map(argToNotRead).join(" || ") + ") return false;");
        cpp.push("  visitor.visit" + definition.name + "(" + args.map(argToName).join(", ") + ");");
        cpp.push("  return true;");
        cpp.push("}");
        cpp.push("");
      } else {
        cpp.push("bool parse" + definition.name + "(kiwi::ByteBuffer &bb, Visitor &visitor) {");
        cpp.push("  visitor.begin" + definition.name + "();");
        for (let j = 0; j < definition.fields.length; j++) {
          let field = definition.fields[j];
          emitReadField(cpp, definitions, definition, field, "  ");
        }
        cpp.push("  visitor.end" + definition.name + "();");
        cpp.push("  return true;");
        cpp.push("}");
        cpp.push("");
      }
    } else if (definition.kind === "MESSAGE") {
      cpp.push("bool parse" + definition.name + "(kiwi::ByteBuffer &bb, Visitor &visitor) {");
      cpp.push("  visitor.begin" + definition.name + "();");
      cpp.push("  while (true) {");
      cpp.push("    uint32_t _type;");
      cpp.push("    if (!bb.readVarUint(_type)) return false;");
      cpp.push("    switch (_type) {");
      cpp.push("      case 0: {");
      cpp.push("        visitor.end" + definition.name + "();");
      cpp.push("        return true;");
      cpp.push("      }");
      for (let j = 0; j < definition.fields.length; j++) {
        let field = definition.fields[j];
        cpp.push("      case " + field.value + ": {");
        emitReadField(cpp, definitions, definition, field, "        ");
        cpp.push("        break;");
        cpp.push("      }");
      }
      cpp.push("      default: return false;");
      cpp.push("    }");
      cpp.push("  }");
      cpp.push("}");
      cpp.push("");
    }
  }
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    if (definition.kind === "STRUCT") {
      let args = extractStructArguments(definitions, "", definition.fields, false);
      if (args !== null) {
        cpp.push("void Writer::visit" + definition.name + "(" + args.map(argToDeclaration).join(", ") + ") {");
        for (let j = 0; j < args.length; j++) {
          cpp.push("  " + argToWrite(args[j]) + ";");
        }
        cpp.push("}");
        cpp.push("");
        continue;
      }
    }
    if (definition.kind === "STRUCT" || definition.kind === "MESSAGE") {
      cpp.push("void Writer::begin" + definition.name + "() {");
      cpp.push("}");
      cpp.push("");
      for (let j = 0; j < definition.fields.length; j++) {
        let field = definition.fields[j];
        if (field.isDeprecated) {
          continue;
        }
        let name = field.name;
        if (field.isArray) {
          cpp.push("void Writer::visit" + definition.name + "_" + field.name + "_count(uint32_t size) {");
          if (definition.kind === "MESSAGE") {
            cpp.push("  _bb.writeVarUint(" + field.value + ");");
          }
          cpp.push("  _bb.writeVarUint(size);");
          cpp.push("}");
          cpp.push("");
          name += "_element";
        }
        let args = extractStructArguments(definitions, "", [field], true);
        if (args !== null) {
          cpp.push("void Writer::visit" + definition.name + "_" + name + "(" + args.map(argToDeclaration).join(", ") + ") {");
          if (definition.kind === "MESSAGE" && !field.isArray) {
            cpp.push("  _bb.writeVarUint(" + field.value + ");");
          }
          for (let k = 0; k < args.length; k++) {
            cpp.push("  " + argToWrite(args[k]) + ";");
          }
          cpp.push("}");
          cpp.push("");
        } else {
          cpp.push("void Writer::visit" + definition.name + "_" + name + "() {");
          if (definition.kind === "MESSAGE" && !field.isArray) {
            cpp.push("  _bb.writeVarUint(" + field.value + ");");
          }
          cpp.push("}");
          cpp.push("");
        }
      }
      cpp.push("void Writer::end" + definition.name + "() {");
      if (definition.kind === "MESSAGE") {
        cpp.push("  _bb.writeVarUint(0);");
      }
      cpp.push("}");
      cpp.push("");
    }
  }
  cpp.push("#endif");
  cpp.push("");
  if (schema.package !== null) {
    cpp.push("}");
    cpp.push("");
    cpp.push("#endif");
    cpp.push("");
  }
  return cpp.join("\n");
}

// cpp.ts
function cppType(definitions, field, isArray) {
  let type;
  switch (field.type) {
    case "bool":
      type = "bool";
      break;
    case "byte":
      type = "uint8_t";
      break;
    case "int":
      type = "int32_t";
      break;
    case "uint":
      type = "uint32_t";
      break;
    case "float":
      type = "float";
      break;
    case "string":
      type = "kiwi::String";
      break;
    default: {
      let definition = definitions[field.type];
      if (!definition) {
        error("Invalid type " + quote(field.type) + " for field " + quote(field.name), field.line, field.column);
      }
      type = definition.name;
      break;
    }
  }
  if (isArray) {
    type = "kiwi::Array<" + type + ">";
  }
  return type;
}
function cppFieldName(field) {
  return "_data_" + field.name;
}
function cppFlagIndex(i) {
  return i >> 5;
}
function cppFlagMask(i) {
  return 1 << i % 32 >>> 0;
}
function cppIsFieldPointer(definitions, field) {
  return !field.isArray && field.type in definitions && definitions[field.type].kind !== "ENUM";
}
function compileSchemaCPP(schema) {
  let definitions = {};
  let cpp = [];
  cpp.push('#include "kiwi.h"');
  cpp.push("");
  if (schema.package !== null) {
    cpp.push("namespace " + schema.package + " {");
    cpp.push("");
    cpp.push("#ifndef INCLUDE_" + schema.package.toUpperCase() + "_H");
    cpp.push("#define INCLUDE_" + schema.package.toUpperCase() + "_H");
    cpp.push("");
  }
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    definitions[definition.name] = definition;
  }
  cpp.push("class BinarySchema {");
  cpp.push("public:");
  cpp.push("  bool parse(kiwi::ByteBuffer &bb);");
  cpp.push("  const kiwi::BinarySchema &underlyingSchema() const { return _schema; }");
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    if (definition.kind === "MESSAGE") {
      cpp.push("  bool skip" + definition.name + "Field(kiwi::ByteBuffer &bb, uint32_t id) const;");
    }
  }
  cpp.push("");
  cpp.push("private:");
  cpp.push("  kiwi::BinarySchema _schema;");
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    if (definition.kind === "MESSAGE") {
      cpp.push("  uint32_t _index" + definition.name + " = 0;");
    }
  }
  cpp.push("};");
  cpp.push("");
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    if (definition.kind === "ENUM") {
      cpp.push("enum class " + definition.name + " : uint32_t {");
      for (let j = 0; j < definition.fields.length; j++) {
        let field = definition.fields[j];
        cpp.push("  " + field.name + " = " + field.value + ",");
      }
      cpp.push("};");
      cpp.push("");
    } else if (definition.kind !== "STRUCT" && definition.kind !== "MESSAGE") {
      error("Invalid definition kind " + quote(definition.kind), definition.line, definition.column);
    }
  }
  for (let pass = 0; pass < 3; pass++) {
    let newline = false;
    if (pass === 2) {
      if (schema.package !== null) {
        cpp.push("#endif");
      }
      cpp.push("#ifdef IMPLEMENT_SCHEMA_H");
      cpp.push("");
      cpp.push("bool BinarySchema::parse(kiwi::ByteBuffer &bb) {");
      cpp.push("  if (!_schema.parse(bb)) return false;");
      for (let i = 0; i < schema.definitions.length; i++) {
        let definition = schema.definitions[i];
        if (definition.kind === "MESSAGE") {
          cpp.push('  _schema.findDefinition("' + definition.name + '", _index' + definition.name + ");");
        }
      }
      cpp.push("  return true;");
      cpp.push("}");
      cpp.push("");
      for (let i = 0; i < schema.definitions.length; i++) {
        let definition = schema.definitions[i];
        if (definition.kind === "MESSAGE") {
          cpp.push("bool BinarySchema::skip" + definition.name + "Field(kiwi::ByteBuffer &bb, uint32_t id) const {");
          cpp.push("  return _schema.skipField(bb, _index" + definition.name + ", id);");
          cpp.push("}");
          cpp.push("");
        }
      }
    }
    for (let i = 0; i < schema.definitions.length; i++) {
      let definition = schema.definitions[i];
      if (definition.kind === "ENUM") {
        continue;
      }
      let fields = definition.fields;
      if (pass === 0) {
        cpp.push("class " + definition.name + ";");
        newline = true;
      } else if (pass === 1) {
        cpp.push("class " + definition.name + " {");
        cpp.push("public:");
        cpp.push("  " + definition.name + "() { (void)_flags; }");
        cpp.push("");
        for (let j = 0; j < fields.length; j++) {
          let field = fields[j];
          if (field.isDeprecated) {
            continue;
          }
          let name = cppFieldName(field);
          let type = cppType(definitions, field, field.isArray);
          let flagIndex = cppFlagIndex(j);
          let flagMask = cppFlagMask(j);
          if (cppIsFieldPointer(definitions, field)) {
            cpp.push("  " + type + " *" + field.name + "();");
            cpp.push("  const " + type + " *" + field.name + "() const;");
            cpp.push("  void set_" + field.name + "(" + type + " *value);");
          } else if (field.isArray) {
            cpp.push("  " + type + " *" + field.name + "();");
            cpp.push("  const " + type + " *" + field.name + "() const;");
            cpp.push("  " + type + " &set_" + field.name + "(kiwi::MemoryPool &pool, uint32_t count);");
          } else {
            cpp.push("  " + type + " *" + field.name + "();");
            cpp.push("  const " + type + " *" + field.name + "() const;");
            cpp.push("  void set_" + field.name + "(const " + type + " &value);");
          }
          cpp.push("");
        }
        cpp.push("  bool encode(kiwi::ByteBuffer &bb);");
        cpp.push("  bool decode(kiwi::ByteBuffer &bb, kiwi::MemoryPool &pool, const BinarySchema *schema = nullptr);");
        cpp.push("");
        cpp.push("private:");
        cpp.push("  uint32_t _flags[" + (fields.length + 31 >> 5) + "] = {};");
        let sizes = { "bool": 1, "byte": 1, "int": 4, "uint": 4, "float": 4 };
        let sortedFields = fields.slice().sort(function(a, b) {
          let sizeA = !a.isArray && sizes[a.type] || 8;
          let sizeB = !b.isArray && sizes[b.type] || 8;
          if (sizeA !== sizeB)
            return sizeB - sizeA;
          return fields.indexOf(a) - fields.indexOf(b);
        });
        for (let j = 0; j < sortedFields.length; j++) {
          let field = sortedFields[j];
          if (field.isDeprecated) {
            continue;
          }
          let name = cppFieldName(field);
          let type = cppType(definitions, field, field.isArray);
          if (cppIsFieldPointer(definitions, field)) {
            cpp.push("  " + type + " *" + name + " = {};");
          } else {
            cpp.push("  " + type + " " + name + " = {};");
          }
        }
        cpp.push("};");
        cpp.push("");
      } else {
        for (let j = 0; j < fields.length; j++) {
          let field = fields[j];
          let name = cppFieldName(field);
          let type = cppType(definitions, field, field.isArray);
          let flagIndex = cppFlagIndex(j);
          let flagMask = cppFlagMask(j);
          if (field.isDeprecated) {
            continue;
          }
          if (cppIsFieldPointer(definitions, field)) {
            cpp.push(type + " *" + definition.name + "::" + field.name + "() {");
            cpp.push("  return " + name + ";");
            cpp.push("}");
            cpp.push("");
            cpp.push("const " + type + " *" + definition.name + "::" + field.name + "() const {");
            cpp.push("  return " + name + ";");
            cpp.push("}");
            cpp.push("");
            cpp.push("void " + definition.name + "::set_" + field.name + "(" + type + " *value) {");
            cpp.push("  " + name + " = value;");
            cpp.push("}");
            cpp.push("");
          } else if (field.isArray) {
            cpp.push(type + " *" + definition.name + "::" + field.name + "() {");
            cpp.push("  return _flags[" + flagIndex + "] & " + flagMask + " ? &" + name + " : nullptr;");
            cpp.push("}");
            cpp.push("");
            cpp.push("const " + type + " *" + definition.name + "::" + field.name + "() const {");
            cpp.push("  return _flags[" + flagIndex + "] & " + flagMask + " ? &" + name + " : nullptr;");
            cpp.push("}");
            cpp.push("");
            cpp.push(type + " &" + definition.name + "::set_" + field.name + "(kiwi::MemoryPool &pool, uint32_t count) {");
            cpp.push("  _flags[" + flagIndex + "] |= " + flagMask + "; return " + name + " = pool.array<" + cppType(definitions, field, false) + ">(count);");
            cpp.push("}");
            cpp.push("");
          } else {
            cpp.push(type + " *" + definition.name + "::" + field.name + "() {");
            cpp.push("  return _flags[" + flagIndex + "] & " + flagMask + " ? &" + name + " : nullptr;");
            cpp.push("}");
            cpp.push("");
            cpp.push("const " + type + " *" + definition.name + "::" + field.name + "() const {");
            cpp.push("  return _flags[" + flagIndex + "] & " + flagMask + " ? &" + name + " : nullptr;");
            cpp.push("}");
            cpp.push("");
            cpp.push("void " + definition.name + "::set_" + field.name + "(const " + type + " &value) {");
            cpp.push("  _flags[" + flagIndex + "] |= " + flagMask + "; " + name + " = value;");
            cpp.push("}");
            cpp.push("");
          }
        }
        cpp.push("bool " + definition.name + "::encode(kiwi::ByteBuffer &_bb) {");
        for (let j = 0; j < fields.length; j++) {
          let field = fields[j];
          if (field.isDeprecated) {
            continue;
          }
          let name = cppFieldName(field);
          let value = field.isArray ? "_it" : name;
          let flagIndex = cppFlagIndex(j);
          let flagMask = cppFlagMask(j);
          let code;
          switch (field.type) {
            case "bool": {
              code = "_bb.writeByte(" + value + ");";
              break;
            }
            case "byte": {
              code = "_bb.writeByte(" + value + ");";
              break;
            }
            case "int": {
              code = "_bb.writeVarInt(" + value + ");";
              break;
            }
            case "uint": {
              code = "_bb.writeVarUint(" + value + ");";
              break;
            }
            case "float": {
              code = "_bb.writeVarFloat(" + value + ");";
              break;
            }
            case "string": {
              code = "_bb.writeString(" + value + ".c_str());";
              break;
            }
            default: {
              let type = definitions[field.type];
              if (!type) {
                error("Invalid type " + quote(field.type) + " for field " + quote(field.name), field.line, field.column);
              } else if (type.kind === "ENUM") {
                code = "_bb.writeVarUint(static_cast<uint32_t>(" + value + "));";
              } else {
                code = "if (!" + value + (cppIsFieldPointer(definitions, field) ? "->" : ".") + "encode(_bb)) return false;";
              }
            }
          }
          let indent = "  ";
          if (definition.kind === "STRUCT") {
            cpp.push("  if (" + field.name + "() == nullptr) return false;");
          } else {
            cpp.push("  if (" + field.name + "() != nullptr) {");
            indent = "    ";
          }
          if (definition.kind === "MESSAGE") {
            cpp.push(indent + "_bb.writeVarUint(" + field.value + ");");
          }
          if (field.isArray) {
            cpp.push(indent + "_bb.writeVarUint(" + name + ".size());");
            cpp.push(indent + "for (" + cppType(definitions, field, false) + " &_it : " + name + ") " + code);
          } else {
            cpp.push(indent + code);
          }
          if (definition.kind !== "STRUCT") {
            cpp.push("  }");
          }
        }
        if (definition.kind === "MESSAGE") {
          cpp.push("  _bb.writeVarUint(0);");
        }
        cpp.push("  return true;");
        cpp.push("}");
        cpp.push("");
        cpp.push("bool " + definition.name + "::decode(kiwi::ByteBuffer &_bb, kiwi::MemoryPool &_pool, const BinarySchema *_schema) {");
        for (let j = 0; j < fields.length; j++) {
          if (fields[j].isArray) {
            cpp.push("  uint32_t _count;");
            break;
          }
        }
        if (definition.kind === "MESSAGE") {
          cpp.push("  while (true) {");
          cpp.push("    uint32_t _type;");
          cpp.push("    if (!_bb.readVarUint(_type)) return false;");
          cpp.push("    switch (_type) {");
          cpp.push("      case 0:");
          cpp.push("        return true;");
        }
        for (let j = 0; j < fields.length; j++) {
          let field = fields[j];
          let name = cppFieldName(field);
          let value = field.isArray ? "_it" : name;
          let isPointer = cppIsFieldPointer(definitions, field);
          let code;
          switch (field.type) {
            case "bool": {
              code = "_bb.readByte(" + value + ")";
              break;
            }
            case "byte": {
              code = "_bb.readByte(" + value + ")";
              break;
            }
            case "int": {
              code = "_bb.readVarInt(" + value + ")";
              break;
            }
            case "uint": {
              code = "_bb.readVarUint(" + value + ")";
              break;
            }
            case "float": {
              code = "_bb.readVarFloat(" + value + ")";
              break;
            }
            case "string": {
              code = "_bb.readString(" + value + ", _pool)";
              break;
            }
            default: {
              let type2 = definitions[field.type];
              if (!type2) {
                error("Invalid type " + quote(field.type) + " for field " + quote(field.name), field.line, field.column);
              } else if (type2.kind === "ENUM") {
                code = "_bb.readVarUint(reinterpret_cast<uint32_t &>(" + value + "))";
              } else {
                code = value + (isPointer ? "->" : ".") + "decode(_bb, _pool, _schema)";
              }
            }
          }
          let type = cppType(definitions, field, false);
          let indent = "  ";
          if (definition.kind === "MESSAGE") {
            cpp.push("      case " + field.value + ": {");
            indent = "        ";
          }
          if (field.isArray) {
            cpp.push(indent + "if (!_bb.readVarUint(_count)) return false;");
            if (field.isDeprecated) {
              cpp.push(indent + "for (" + type + " &_it : _pool.array<" + cppType(definitions, field, false) + ">(_count)) if (!" + code + ") return false;");
            } else {
              cpp.push(indent + "for (" + type + " &_it : set_" + field.name + "(_pool, _count)) if (!" + code + ") return false;");
            }
          } else {
            if (field.isDeprecated) {
              if (isPointer) {
                cpp.push(indent + type + " *" + name + " = _pool.allocate<" + type + ">();");
              } else {
                cpp.push(indent + type + " " + name + " = {};");
              }
              cpp.push(indent + "if (!" + code + ") return false;");
            } else {
              if (isPointer) {
                cpp.push(indent + name + " = _pool.allocate<" + type + ">();");
              }
              cpp.push(indent + "if (!" + code + ") return false;");
              if (!isPointer) {
                cpp.push(indent + "set_" + field.name + "(" + name + ");");
              }
            }
          }
          if (definition.kind === "MESSAGE") {
            cpp.push("        break;");
            cpp.push("      }");
          }
        }
        if (definition.kind === "MESSAGE") {
          cpp.push("      default: {");
          cpp.push("        if (!_schema || !_schema->skip" + definition.name + "Field(_bb, _type)) return false;");
          cpp.push("        break;");
          cpp.push("      }");
          cpp.push("    }");
          cpp.push("  }");
        } else {
          cpp.push("  return true;");
        }
        cpp.push("}");
        cpp.push("");
      }
    }
    if (pass === 2) {
      cpp.push("#endif");
      cpp.push("");
    } else if (newline)
      cpp.push("");
  }
  if (schema.package !== null) {
    cpp.push("}");
    cpp.push("");
  }
  return cpp.join("\n");
}

// skew.ts
function popTrailingNewline(lines) {
  if (lines[lines.length - 1] === "") {
    lines.pop();
  }
}
function skewDefaultValueForField(definitions, field) {
  if (field.isArray) {
    return "null";
  }
  switch (field.type) {
    case "bool":
      return "false";
    case "byte":
    case "int":
    case "uint":
      return "0";
    case "float":
      return "0.0";
    case "string":
      return "null";
  }
  let def = definitions[field.type];
  if (def.kind === "ENUM") {
    if (def.fields.length > 0) {
      return "." + def.fields[0].name;
    }
    return "0 as " + field.type;
  }
  return "null";
}
function skewTypeForField(field) {
  let type;
  switch (field.type) {
    case "bool":
      type = "bool";
      break;
    case "byte":
    case "int":
    case "uint":
      type = "int";
      break;
    case "float":
      type = "double";
      break;
    case "string":
      type = "string";
      break;
    default:
      type = field.type;
      break;
  }
  if (field.isArray) {
    type = "List<" + type + ">";
  }
  return type;
}
function compileSchemaSkew(schema) {
  let definitions = {};
  let indent = "";
  let lines = [];
  if (schema.package !== null) {
    lines.push("namespace " + schema.package + " {");
    indent += "  ";
  }
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    definitions[definition.name] = definition;
  }
  lines.push(indent + "class BinarySchema {");
  lines.push(indent + "  var _schema = Kiwi.BinarySchema.new");
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    if (definition.kind === "MESSAGE") {
      lines.push(indent + "  var _index" + definition.name + " = 0");
    }
  }
  lines.push("");
  lines.push(indent + "  def parse(bytes Uint8Array) {");
  lines.push(indent + "    _schema.parse(Kiwi.ByteBuffer.new(bytes))");
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    if (definition.kind === "MESSAGE") {
      lines.push(indent + "    _index" + definition.name + ' = _schema.findDefinition("' + definition.name + '")');
    }
  }
  lines.push(indent + "  }");
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    if (definition.kind === "MESSAGE") {
      lines.push("");
      lines.push(indent + "  def skip" + definition.name + "Field(bb Kiwi.ByteBuffer, id int) {");
      lines.push(indent + "    _schema.skipField(bb, _index" + definition.name + ", id)");
      lines.push(indent + "  }");
    }
  }
  lines.push(indent + "}");
  lines.push("");
  for (let i = 0; i < schema.definitions.length; i++) {
    let definition = schema.definitions[i];
    switch (definition.kind) {
      case "ENUM": {
        let encode = {};
        let decode = {};
        lines.push(indent + "enum " + definition.name + " {");
        for (let j = 0; j < definition.fields.length; j++) {
          let field = definition.fields[j];
          encode[field.name] = field.value;
          decode[field.value] = field.name;
          lines.push(indent + "  " + field.name);
        }
        lines.push(indent + "}");
        lines.push("");
        lines.push(indent + "namespace " + definition.name + " {");
        lines.push(indent + "  const _encode = " + JSON.stringify(encode, null, 2).replace(/"/g, "").replace(/\n/g, "\n  " + indent));
        lines.push("");
        lines.push(indent + "  const _decode = " + JSON.stringify(decode, null, 2).replace(/"/g, "").replace(/\n/g, "\n  " + indent));
        lines.push("");
        lines.push(indent + "  def encode(value " + definition.name + ") int {");
        lines.push(indent + "    return _encode[value]");
        lines.push(indent + "  }");
        lines.push("");
        lines.push(indent + "  def decode(value int) " + definition.name + " {");
        lines.push(indent + "    if !(value in _decode) {");
        lines.push(indent + "      Kiwi.DecodeError.throwInvalidEnumValue(" + quote(definition.name) + ")");
        lines.push(indent + "    }");
        lines.push(indent + "    return _decode[value]");
        lines.push(indent + "  }");
        lines.push(indent + "}");
        lines.push("");
        break;
      }
      case "STRUCT":
      case "MESSAGE": {
        lines.push(indent + "class " + definition.name + " {");
        for (let j = 0; j < definition.fields.length; j += 32) {
          lines.push(indent + "  var _flags" + (j >> 5) + " = 0");
        }
        for (let j = 0; j < definition.fields.length; j++) {
          let field = definition.fields[j];
          if (field.isDeprecated) {
            continue;
          }
          lines.push(indent + "  var _" + field.name + " " + skewTypeForField(field) + " = " + skewDefaultValueForField(definitions, field));
        }
        lines.push("");
        for (let j = 0; j < definition.fields.length; j++) {
          let field = definition.fields[j];
          if (field.isDeprecated) {
            continue;
          }
          let type = skewTypeForField(field);
          let flags = "_flags" + (j >> 5);
          let mask = "" + (1 << j % 32 >>> 0);
          lines.push(indent + "  def has_" + field.name + " bool {");
          lines.push(indent + "    return (" + flags + " & " + mask + ") != 0");
          lines.push(indent + "  }");
          lines.push("");
          lines.push(indent + "  def " + field.name + " " + type + " {");
          lines.push(indent + "    assert(has_" + field.name + ")");
          lines.push(indent + "    return _" + field.name);
          lines.push(indent + "  }");
          lines.push("");
          lines.push(indent + "  def " + field.name + "=(value " + type + ") {");
          lines.push(indent + "    _" + field.name + " = value");
          lines.push(indent + "    " + flags + " |= " + mask);
          lines.push(indent + "  }");
          lines.push("");
        }
        lines.push(indent + "  def encode(bb Kiwi.ByteBuffer) {");
        for (let j = 0; j < definition.fields.length; j++) {
          let field = definition.fields[j];
          if (field.isDeprecated) {
            continue;
          }
          let value = "_" + field.name;
          let code;
          if (field.isArray) {
            value = "value";
          }
          switch (field.type) {
            case "bool": {
              code = "bb.writeByte(" + value + " as int)";
              break;
            }
            case "byte": {
              code = "bb.writeByte(" + value + ")";
              break;
            }
            case "int": {
              code = "bb.writeVarInt(" + value + ")";
              break;
            }
            case "uint": {
              code = "bb.writeVarUint(" + value + ")";
              break;
            }
            case "float": {
              code = "bb.writeVarFloat(" + value + ")";
              break;
            }
            case "string": {
              code = "bb.writeString(" + value + ")";
              break;
            }
            default: {
              let type = definitions[field.type];
              if (!type) {
                error("Invalid type " + quote(field.type) + " for field " + quote(field.name), field.line, field.column);
              } else if (type.kind === "ENUM") {
                code = "bb.writeVarUint(" + type.name + ".encode(" + value + "))";
              } else {
                code = value + ".encode(bb)";
              }
            }
          }
          let nestedIndent2 = indent + "    ";
          if (definition.kind === "STRUCT") {
            lines.push(nestedIndent2 + "assert(has_" + field.name + ")");
          } else {
            lines.push(nestedIndent2 + "if has_" + field.name + " {");
            nestedIndent2 += "  ";
          }
          if (definition.kind === "MESSAGE") {
            lines.push(nestedIndent2 + "bb.writeVarUint(" + field.value + ")");
          }
          if (field.isArray) {
            lines.push(nestedIndent2 + "bb.writeVarUint(_" + field.name + ".count)");
            lines.push(nestedIndent2 + "for value in _" + field.name + " {");
            lines.push(nestedIndent2 + "  " + code);
            lines.push(nestedIndent2 + "}");
          } else {
            lines.push(nestedIndent2 + code);
          }
          if (definition.kind !== "STRUCT") {
            lines.push(indent + "    }");
          }
          lines.push("");
        }
        if (definition.kind === "MESSAGE") {
          lines.push(indent + "    bb.writeVarUint(0)");
        } else {
          popTrailingNewline(lines);
        }
        lines.push(indent + "  }");
        lines.push("");
        lines.push(indent + "  def encode Uint8Array {");
        lines.push(indent + "    var bb = Kiwi.ByteBuffer.new");
        lines.push(indent + "    encode(bb)");
        lines.push(indent + "    return bb.toUint8Array");
        lines.push(indent + "  }");
        lines.push(indent + "}");
        lines.push("");
        lines.push(indent + "namespace " + definition.name + " {");
        lines.push(indent + "  def decode(bytes Uint8Array) " + definition.name + " {");
        lines.push(indent + "    return decode(Kiwi.ByteBuffer.new(bytes), null)");
        lines.push(indent + "  }");
        lines.push("");
        lines.push(indent + "  def decode(bytes Uint8Array, schema BinarySchema) " + definition.name + " {");
        lines.push(indent + "    return decode(Kiwi.ByteBuffer.new(bytes), schema)");
        lines.push(indent + "  }");
        lines.push("");
        lines.push(indent + "  def decode(bb Kiwi.ByteBuffer, schema BinarySchema) " + definition.name + " {");
        lines.push(indent + "    var self = new");
        for (let j = 0; j < definition.fields.length; j++) {
          if (definition.fields[j].isArray) {
            lines.push(indent + "    var count = 0");
            break;
          }
        }
        let nestedIndent = indent + "  ";
        if (definition.kind === "MESSAGE") {
          lines.push(indent + "    while true {");
          lines.push(indent + "      var type = bb.readVarUint");
          lines.push(indent + "      switch type {");
          lines.push(indent + "        case 0 {");
          lines.push(indent + "          break");
          lines.push(indent + "        }");
          lines.push("");
          nestedIndent += "      ";
        }
        for (let j = 0; j < definition.fields.length; j++) {
          let field = definition.fields[j];
          let code;
          switch (field.type) {
            case "bool": {
              code = field.isDeprecated ? "bb.readByte" : "bb.readByte as bool";
              break;
            }
            case "byte": {
              code = "bb.readByte";
              break;
            }
            case "int": {
              code = "bb.readVarInt";
              break;
            }
            case "uint": {
              code = "bb.readVarUint";
              break;
            }
            case "float": {
              code = "bb.readVarFloat";
              break;
            }
            case "string": {
              code = "bb.readString";
              break;
            }
            default: {
              let type = definitions[field.type];
              if (!type) {
                error("Invalid type " + quote(field.type) + " for field " + quote(field.name), field.line, field.column);
              } else if (type.kind === "ENUM") {
                code = type.name + ".decode(bb.readVarUint)";
              } else {
                code = type.name + ".decode(bb, schema)";
              }
            }
          }
          if (definition.kind === "MESSAGE") {
            lines.push(nestedIndent + "case " + field.value + " {");
          }
          if (field.isArray) {
            if (field.isDeprecated) {
              lines.push(nestedIndent + "  for i in 0..bb.readVarUint {");
              lines.push(nestedIndent + "    " + code);
              lines.push(nestedIndent + "  }");
            } else {
              lines.push(nestedIndent + "  count = bb.readVarUint");
              lines.push(nestedIndent + "  self." + field.name + " = []");
              lines.push(nestedIndent + "  for array = self._" + field.name + "; count != 0; count-- {");
              lines.push(nestedIndent + "    array.append(" + code + ")");
              lines.push(nestedIndent + "  }");
            }
          } else {
            if (field.isDeprecated) {
              lines.push(nestedIndent + "  " + code);
            } else {
              lines.push(nestedIndent + "  self." + field.name + " = " + code);
            }
          }
          if (definition.kind === "MESSAGE") {
            lines.push(nestedIndent + "}");
            lines.push("");
          }
        }
        if (definition.kind === "MESSAGE") {
          lines.push(indent + "        default {");
          lines.push(indent + "          if schema == null { Kiwi.DecodeError.throwInvalidMessage }");
          lines.push(indent + "          else { schema.skip" + definition.name + "Field(bb, type) }");
          lines.push(indent + "        }");
          lines.push(indent + "      }");
          lines.push(indent + "    }");
        }
        lines.push(indent + "    return self");
        lines.push(indent + "  }");
        lines.push(indent + "}");
        lines.push("");
        break;
      }
      default: {
        error("Invalid definition kind " + quote(definition.kind), definition.line, definition.column);
        break;
      }
    }
  }
  if (schema.package !== null) {
    popTrailingNewline(lines);
    lines.push("}");
  }
  lines.push("");
  return lines.join("\n");
}

// skew-types.ts
function compileSchemaSkewTypes(schema) {
  var indent = "";
  var lines = [];
  if (schema.package !== null) {
    lines.push("namespace " + schema.package + " {");
    indent += "  ";
  }
  for (var i = 0; i < schema.definitions.length; i++) {
    var definition = schema.definitions[i];
    if (definition.kind === "ENUM") {
      lines.push(indent + "type " + definition.name + " : string {");
      lines.push(indent + "  @alwaysinline");
      lines.push(indent + "  def toString string { return self as string }");
      lines.push(indent + "}");
      if (definition.fields.length > 0) {
        lines.push(indent + "namespace " + definition.name + " {");
        for (var j = 0; j < definition.fields.length; j++) {
          lines.push(indent + "  @alwaysinline");
          lines.push(indent + "  def " + definition.fields[j].name + " " + definition.name + " { return " + JSON.stringify(definition.fields[j].name) + " as " + definition.name + " }");
        }
        lines.push(indent + "}");
      }
      lines.push("");
    }
  }
  for (var i = 0; i < schema.definitions.length; i++) {
    var definition = schema.definitions[i];
    if (definition.kind === "STRUCT" || definition.kind === "MESSAGE") {
      lines.push(indent + "@import");
      lines.push(indent + "class " + definition.name + " {");
      for (var j = 0; j < definition.fields.length; j++) {
        var field = definition.fields[j];
        var type;
        if (field.isDeprecated) {
          continue;
        }
        switch (field.type) {
          case "byte":
          case "uint":
            type = "int";
            break;
          case "float":
            type = "double";
            break;
          default:
            type = field.type;
            break;
        }
        if (field.type === "byte" && field.isArray)
          type = "Uint8Array";
        else if (field.isArray)
          type = "List<" + type + ">";
        lines.push(indent + "  var " + field.name + " " + type);
        lines.push(indent + "  @alwaysinline");
        lines.push(indent + "  def has_" + field.name + " bool { return self." + field.name + " != dynamic.void(0) }");
      }
      lines.push(indent + "}");
      lines.push("");
      lines.push(indent + "namespace " + definition.name + " {");
      lines.push(indent + "  @alwaysinline");
      lines.push(indent + "  def new " + definition.name + " { return {} as dynamic }");
      lines.push(indent + "}");
      lines.push("");
    } else if (definition.kind !== "ENUM") {
      error("Invalid definition kind " + quote(definition.kind), definition.line, definition.column);
    }
  }
  lines.push(indent + "@import");
  lines.push(indent + "class Schema {");
  for (var i = 0; i < schema.definitions.length; i++) {
    var definition = schema.definitions[i];
    if (definition.kind === "ENUM") {
      lines.push(indent + "  const " + definition.name + " dynamic");
    } else if (definition.kind === "STRUCT" || definition.kind === "MESSAGE") {
      lines.push(indent + "  def encode" + definition.name + "(message " + definition.name + ") Uint8Array");
      lines.push(indent + "  def decode" + definition.name + "(buffer Uint8Array) " + definition.name);
    }
  }
  lines.push(indent + "}");
  if (schema.package !== null) {
    lines.push("}");
  }
  lines.push("");
  return lines.join("\n");
}

// ts.ts
var KIWI_IMPORT_PATH = "peechy";
function compileSchemaTypeScript(schema) {
  var indent = "";
  var lines = [`import type {ByteBuffer} from "${KIWI_IMPORT_PATH}/bb";
`];
  if (schema.package !== null) {
    indent += "  ";
  }
  lines.push(`type byte = number;`);
  lines.push(`type float = number;`);
  lines.push(`type int = number;`);
  lines.push(`type alphanumeric = string;`);
  lines.push(`type uint = number;`);
  lines.push(`type int8 = number;`);
  lines.push(`type uint8 = number;`);
  lines.push(`type lowp = number;`);
  lines.push(`type int16 = number;`);
  lines.push(`type int32 = number;`);
  lines.push(`type float32 = number;`);
  lines.push(`type uint16 = number;`);
  lines.push(`type uint32 = number;`);
  var unionsByName = {};
  var discriminatedTypes = {};
  for (var i = 0; i < schema.definitions.length; i++) {
    var definition = schema.definitions[i];
    if (definition.kind === "UNION") {
      unionsByName[definition.name] = i;
      lines.push(indent + "export const enum " + definition.name + "Type {");
      const descriminator = definition.fields[0];
      for (var j = 0; j < definition.fields.length; ) {
        const field2 = definition.fields[j];
        if (descriminator.type === "discriminator") {
          if (j === 0) {
            j++;
            continue;
          }
          if (!discriminatedTypes[field2.name]) {
            discriminatedTypes[field2.type] = {
              [descriminator.name]: definition.name + "Type." + field2.name
            };
          } else {
            discriminatedTypes[field2.type][descriminator.name] = definition.name + "Type." + field2.name;
          }
        }
        lines.push(
          indent + indent + "" + field2.name + " = " + field2.value + (j < definition.fields.length - 1 ? "," : "")
        );
        j++;
      }
      lines.push(indent + "}");
      lines.push(indent + "export const " + definition.name + "Keys: {");
      for (var j = 0; j < definition.fields.length; ) {
        const field2 = definition.fields[j];
        if (descriminator.type === "discriminator") {
          if (j === 0) {
            j++;
            continue;
          }
        }
        lines.push(
          indent + indent + "" + field2.value + ': "' + field2.name + '",',
          indent + indent + "" + field2.name + ': "' + field2.name + '"' + (j < definition.fields.length - 1 ? "," : "")
        );
        j++;
      }
      lines.push(indent + "}");
    } else if (definition.kind === "ENUM" || definition.kind === "SMOL") {
      if (!definition.fields.length) {
        lines.push(indent + "export type " + definition.name + " = any;");
      } else {
        lines.push(indent + "export const enum " + definition.name + " {");
        for (var j = 0; j < definition.fields.length; j++) {
          lines.push(
            indent + indent + "" + definition.fields[j].name + " = " + definition.fields[j].value + (j < definition.fields.length - 1 ? "," : "")
          );
        }
        lines.push(indent + "}");
        lines.push(indent + "export const " + definition.name + "Keys: {");
        for (var j = 0; j < definition.fields.length; j++) {
          lines.push(
            indent + indent + "" + definition.fields[j].value + `: "${definition.fields[j].name}",`,
            indent + indent + "" + definition.fields[j].name + `: "${definition.fields[j].name}"` + (j < definition.fields.length - 1 ? "," : "")
          );
        }
        lines.push(indent + "}");
      }
    } else if (definition.kind === "ALIAS") {
      lines.push(
        indent + "export type " + definition.name + " = " + definition.fields[0].name + ";"
      );
    }
  }
  for (var i = 0; i < schema.definitions.length; i++) {
    var definition = schema.definitions[i];
    if (definition.kind === "ALIAS")
      continue;
    const unionFields = {};
    let unionFieldsCount = 0;
    for (var j = 0; j < definition.fields.length; j++) {
      var field = definition.fields[j];
      if (field.type && unionsByName[field.type] && (!discriminatedTypes[definition.name] || !discriminatedTypes[definition.name][field.name])) {
        unionFields[field.type] = j;
        unionFieldsCount++;
      }
    }
    if (definition.kind === "STRUCT" || definition.kind === "MESSAGE" || definition.kind === "UNION") {
      let line;
      if (definition.kind === "UNION") {
        line = indent + "export type " + definition.name;
      } else if (unionFieldsCount) {
        line = indent + "interface Abstract" + definition.name;
      } else {
        line = indent + "export interface " + definition.name;
      }
      const discriminators = discriminatedTypes[definition.name];
      if (discriminators) {
        let index = 0;
        const discriminatorNames = [];
        for (let discriminator in discriminators) {
          discriminatorNames.push(
            "U" + index++ + ` extends (${discriminators[discriminator]} | undefined) = undefined`
          );
        }
        line += "<" + discriminatorNames.join(" , ") + ">";
        if (definition.kind === "UNION") {
          line += " =";
        }
        line += " {";
        lines.push(line);
        index = 0;
        for (let discriminator in discriminators) {
          lines.push(indent + indent + `${discriminator}: U${index++};`);
        }
        if (definition.kind === "UNION") {
          lines.push("  }");
        }
      } else if (definition.kind !== "UNION") {
        line += " {";
        lines.push(line);
      } else {
        line += " = ";
        lines.push(line);
      }
      let isFirstNewField = true;
      for (var j = 0; j < definition.fields.length; j++) {
        var field = definition.fields[j];
        var type;
        if (field.isDeprecated) {
          continue;
        }
        switch (field.type) {
          case "bool":
            type = "boolean";
            break;
          case "byte":
          case "float":
          case "int":
          case "uint":
          case "int8":
          case "int16":
          case "int32":
          case "float32":
          case "uint16":
          case "uint32":
            type = field.type;
            break;
          case "string": {
            type = "string";
            break;
          }
          default:
            type = field.type;
            break;
        }
        if (field.type === "byte" && field.isArray)
          type = "Uint8Array";
        else if (field.type === "int8" && field.isArray)
          type = "Int8Array";
        else if (field.type === "int16" && field.isArray)
          type = "Int16Array";
        else if (field.type === "int32" && field.isArray)
          type = "Int32Array";
        else if (field.type === "float32" && field.isArray)
          type = "Float32Array";
        else if (field.type === "uint16" && field.isArray)
          type = "Uint16Array";
        else if (field.type === "uint32" && field.isArray)
          type = "Uint32Array";
        else if (field.isArray)
          type += "[]";
        if (definition.kind === "UNION") {
          if (discriminators && isFirstNewField) {
            lines.push(" & (");
          }
          if (field.type !== "discriminator") {
            if (discriminatedTypes[field.type]) {
              lines.push(
                indent + indent + "|" + indent + field.name + "<" + definition.name + "Type." + field.name + "> "
              );
            } else {
              lines.push(indent + indent + "|" + indent + field.name);
            }
          }
        } else {
          lines.push(
            indent + "  " + field.name + (definition.kind === "MESSAGE" && !field.isRequired ? "?" : "") + ": " + type + ";"
          );
        }
        isFirstNewField = false;
      }
      if (definition.kind === "UNION" && !discriminatedTypes[definition.name]) {
        lines[lines.length - 1] = lines[lines.length - 1].substring(0, lines[lines.length - 1].length) + ";";
      } else if (definition.kind === "UNION") {
        lines[lines.length - 1] += ");";
      } else {
        lines.push(indent + "}");
        lines.push("");
      }
      if (unionFieldsCount) {
        const unionTypeNames = [];
        for (let type2 in unionFields) {
          const fieldId = unionFields[type2];
          const field2 = definition.fields[fieldId];
          const union = field2.type && schema.definitions[unionsByName[field2.type]];
          if (union) {
            const group = [];
            for (let value of union.fields) {
              if (value.type === "discriminator")
                break;
              const unionTypeName = `${definition.name}${value.name}Discriminator`;
              group.push(unionTypeName);
              if (value.type) {
                const discriminator = `${union.name}Type.${value.type}`;
                lines.push(
                  `type ${unionTypeName} = { ${field2.name}Type${field2.isRequired ? "" : "?"}: ${discriminator}; ${field2.name}${field2.isRequired ? "" : "?"}: ${value.type}; }`
                );
              }
            }
            if (group.length)
              unionTypeNames.push(group);
          }
        }
        const unionTypeString = unionTypeNames.map(
          (group) => group.length > 0 ? "( " + group.join(" | ") + " )" : ""
        ).filter((a) => a.trim().length > 0).join(" & ");
        if (unionTypeString.length) {
          let types2 = "";
          let typeNames = "";
          if (discriminators) {
            let index = 0;
            const discriminatorNames = [];
            const typeNameList = [];
            for (let discriminator in discriminators) {
              const typeName = "U" + index++;
              typeNameList.push(typeName);
              discriminatorNames.push(
                typeName + ` extends (${discriminators[discriminator]} | undefined) = undefined`
              );
            }
            types2 = "<" + discriminatorNames.join(" , ") + ">";
            typeNames = "<" + typeNameList.join(" , ") + ">";
          }
          lines.push(
            `export type ${definition.name}${types2} = Abstract${definition.name}${typeNames} & ${unionTypeString};`
          );
        } else if (discriminators) {
          let types2 = "";
          let typeNames = "";
          if (discriminators) {
            let index = 0;
            const discriminatorNames = [];
            const typeNameList = [];
            for (let discriminator in discriminators) {
              const typeName = "U" + index++;
              typeNameList.push(typeName);
              discriminatorNames.push(
                typeName + ` extends (${discriminators[discriminator]} | undefined) = undefined`
              );
            }
            types2 = "<" + discriminatorNames.join(" , ") + ">";
            typeNames = "<" + typeNameList.join(" , ") + ">";
          }
          lines.push(`
            export interface ${definition.name}${types2} extends Abstract${definition.name}${typeNames} {}
          `);
        } else if (definition.kind !== "UNION") {
          lines.push(
            `export interface ${definition.name} extends Abstract${definition.name} {};`
          );
        }
      }
    } else if (definition.kind !== "ENUM" && definition.kind !== "SMOL") {
      error(
        "Invalid definition kind " + quote(definition.kind),
        definition.line,
        definition.column
      );
    }
  }
  for (var i = 0; i < schema.definitions.length; i++) {
    var definition = schema.definitions[i];
    if (definition.kind === "ENUM") {
    } else if (definition.kind === "STRUCT" || definition.kind === "MESSAGE" || definition.kind === "UNION") {
      if (definition.kind === "UNION") {
        if (definition.fields[0].type !== "discriminator") {
          lines.push(
            indent + "export declare function  encode" + definition.name + "(message: " + definition.name + `, bb: ByteBuffer, type: ${definition.name}Type): void;`
          );
        } else {
          lines.push(
            indent + "export declare function  encode" + definition.name + "(message: " + definition.name + ", bb: ByteBuffer): void;"
          );
        }
      } else {
        lines.push(
          indent + "export declare function  encode" + definition.name + "(message: " + definition.name + ", bb: ByteBuffer): void;"
        );
      }
      lines.push(
        indent + "export declare function decode" + definition.name + "(buffer: ByteBuffer): " + definition.name + ";"
      );
    }
  }
  lines.push("");
  return lines.join("\n");
}

// binary.ts
var types = [
  "bool",
  "byte",
  "float",
  "int",
  "uint8",
  "uint16",
  "uint32",
  "int8",
  "int16",
  "int32",
  "float32",
  "string",
  "uint"
];
var kinds = [
  "ENUM",
  "STRUCT",
  "MESSAGE",
  "UNION",
  "SMOL",
  "ALIAS"
];
function decodeBinarySchema(buffer) {
  let bb = buffer instanceof ByteBuffer ? buffer : new ByteBuffer(buffer);
  let definitionCount = bb.readVarUint();
  let definitions = [];
  for (let i = 0; i < definitionCount; i++) {
    let definitionName = bb.readString();
    let kind = bb.readByte();
    let fieldCount = bb.readVarUint();
    let fields = [];
    for (let j = 0; j < fieldCount; j++) {
      let fieldName = bb.readString();
      let type = bb.readVarInt();
      let isArray = !!(bb.readByte() & 1);
      let isRequired = !!(bb.readByte() & 1);
      let value = bb.readVarUint();
      fields.push({
        name: fieldName,
        line: 0,
        column: 0,
        type: kinds[kind] === "ENUM" || kinds[kind] === "SMOL" ? null : type,
        isArray,
        isRequired,
        isDeprecated: false,
        value
      });
    }
    let serializerPath = bb.readString();
    definitions.push({
      name: definitionName,
      line: 0,
      column: 0,
      kind: kinds[kind],
      fields,
      serializerPath
    });
  }
  for (let i = 0; i < definitionCount; i++) {
    let fields = definitions[i].fields;
    for (let j = 0; j < fields.length; j++) {
      let field = fields[j];
      let type = field.type;
      if (type !== null && type < 0) {
        if (~type >= types.length) {
          throw new Error("Invalid type " + type);
        }
        field.type = types[~type];
      } else {
        if (type !== null && type >= definitions.length) {
          throw new Error("Invalid type " + type);
        }
        field.type = type === null ? null : definitions[type].name;
      }
    }
  }
  return {
    package: null,
    definitions
  };
}
function encodeBinarySchema(schema) {
  let bb = new ByteBuffer();
  let definitions = schema.definitions;
  let definitionIndex = {};
  bb.writeVarUint(definitions.length);
  for (let i = 0; i < definitions.length; i++) {
    definitionIndex[definitions[i].name] = i;
  }
  for (let i = 0; i < definitions.length; i++) {
    let definition = definitions[i];
    bb.writeString(definition.name);
    bb.writeByte(kinds.indexOf(definition.kind));
    bb.writeVarUint(definition.fields.length);
    for (let j = 0; j < definition.fields.length; j++) {
      let field = definition.fields[j];
      let type = types.indexOf(field.type);
      bb.writeString(field.name);
      bb.writeVarInt(type === -1 ? definitionIndex[field.type] : ~type);
      bb.writeByte(field.isArray ? 1 : 0);
      bb.writeByte(field.isRequired ? 1 : 0);
      bb.writeVarUint(field.value);
    }
    bb.writeString(definition.serializerPath || "");
  }
  return bb.toUint8Array();
}

// printer.ts
function prettyPrintSchema(schema) {
  let definitions = schema.definitions;
  let text = "";
  let discriminatorIndex = -1;
  if (schema.package !== null) {
    text += "package " + schema.package + ";\n";
  }
  for (let i = 0; i < definitions.length; i++) {
    let definition = definitions[i];
    if (i > 0 || schema.package !== null)
      text += "\n";
    if (definition.kind === "UNION") {
      discriminatorIndex = -1;
      text += definition.kind.toLowerCase() + " " + definition.name + " = ";
      for (let j = 0; j < definition.fields.length; j++) {
        let field = definition.fields[j];
        if (field.value === 0) {
          discriminatorIndex = j;
          continue;
        }
        text += field.name;
        if (j < definition.fields.length - 1) {
          text += " | ";
        }
      }
      if (discriminatorIndex > -1) {
        text += " {\n";
        text += "  " + definition.fields[discriminatorIndex].name + ";\n";
        text += "}\n";
      } else {
        text += ";\n";
      }
    } else if (definition.kind === "ALIAS") {
      text += definition.kind.toLowerCase() + " " + definition.name + " = ";
      text += definition.fields[0].name;
      text += ";\n";
    } else {
      text += definition.kind.toLowerCase() + " " + definition.name + " {\n";
      for (let j = 0; j < definition.fields.length; j++) {
        let field = definition.fields[j];
        text += "  ";
        if (definition.kind !== "ENUM") {
          text += field.type;
          if (field.isArray) {
            text += "[]";
          }
          text += " ";
        }
        text += field.name;
        if (definition.kind !== "STRUCT") {
          text += " = " + field.value;
        }
        if (field.isDeprecated) {
          text += " [deprecated]";
        }
        text += ";\n";
      }
      text += "}\n";
    }
  }
  return text;
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  ByteBuffer,
  compileSchema,
  compileSchemaCPP,
  compileSchemaCallbackCPP,
  compileSchemaJS,
  compileSchemaSkew,
  compileSchemaSkewTypes,
  compileSchemaTypeScript,
  decodeBinarySchema,
  encodeBinarySchema,
  parseSchema,
  prettyPrintSchema
});
