/**
 * @typedef {Object} Foo
 * @property {number} a
 */
export default /** @satisfies {Foo} */ ({});
