/** @typedef {number} Dotted.Name */
export var dummy = 1
