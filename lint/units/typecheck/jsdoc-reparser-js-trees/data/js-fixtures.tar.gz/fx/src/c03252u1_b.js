/** @augments A<number> */
class B extends A {
    m() {
        return this.x;
    }
}
