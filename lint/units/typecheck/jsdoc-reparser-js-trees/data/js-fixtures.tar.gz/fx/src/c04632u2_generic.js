/**
 * @template T
 * @param {T} flavour
 */
function Soup(flavour) {
    this.flavour = flavour
}
/** @extends {Soup<{ claim: "ignorant" | "malicious" }>} */
class Chowder extends Soup {
    log() {
        return this.flavour
    }
}

var soup = new Soup(1);
soup.flavour
var chowder = new Chowder({ claim: "ignorant" });
chowder.flavour.claim
var errorNoArgs = new Chowder();
var errorArgType = new Chowder(0);

