/**
  * @type {number}
  * @type {string}
  */
var v;
