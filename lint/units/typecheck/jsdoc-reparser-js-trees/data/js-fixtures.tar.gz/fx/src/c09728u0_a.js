/** @param {...number} a */
function f(...a) {
    a; // number[]
}
