export type foo = 5;
/**
 * @typedef {{
 * }}
 */
export const foo = 5;