/**
 * @template {string} T
 * @typedef {{ foo: T }} Foo
 */

export default {};
