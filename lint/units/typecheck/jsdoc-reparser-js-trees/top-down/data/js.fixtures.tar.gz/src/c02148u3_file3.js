// error
export @dec default class C3 {}
