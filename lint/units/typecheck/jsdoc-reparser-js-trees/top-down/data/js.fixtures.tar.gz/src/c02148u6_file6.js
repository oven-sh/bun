// error
@dec export @dec class C6 {}
