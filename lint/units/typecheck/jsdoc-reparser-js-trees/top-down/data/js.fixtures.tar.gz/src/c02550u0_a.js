var v = undefined satisfies 1;
