import ns = require("./cls");
export = ns; // TS Only
