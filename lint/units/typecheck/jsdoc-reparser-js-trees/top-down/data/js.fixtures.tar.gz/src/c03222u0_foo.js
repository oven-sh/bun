/** @import * as f from "./foo" with */
