/**
 * @import * as NS from './a'
 */

/** @implements {NS.I} */
export class C {}
