/** {@link Map.delete} */
const remove = (map, key) => {}
