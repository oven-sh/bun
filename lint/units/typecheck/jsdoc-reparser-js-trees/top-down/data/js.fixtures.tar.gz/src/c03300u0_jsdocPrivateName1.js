// Expecting parse error for private field

/**
 * @typedef A
 * @type {object}
 * @property {string} #id
 */
