function repeat(
	/** @type {string} */ message,
	/** @type {number} */ times,
) {
	return Array(times).fill(message).join(` `);
}

/** @type {Parameters<typeof repeat>[0]} */
const message = `hello`;

/** @type {Parameters<typeof repeat>[1]} */
const times = 3;
