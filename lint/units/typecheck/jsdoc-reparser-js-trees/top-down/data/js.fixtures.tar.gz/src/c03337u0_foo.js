/** @type {boolean} */
var /** @type {string} */ x,
    /** @type {number} */ y;
