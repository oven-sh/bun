class B {
    foo (v) {}
    fooo (v) {}
}

class D extends B {
    override foo (v) {}
    /** @override */
    fooo (v) {}
}
