/**
 * @deprecated
 */
export { default as A } from "./a";
