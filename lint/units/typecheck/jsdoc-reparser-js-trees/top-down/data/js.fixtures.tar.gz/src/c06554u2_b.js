/** @type {import("./a").Foo} */
export default { c: false };
