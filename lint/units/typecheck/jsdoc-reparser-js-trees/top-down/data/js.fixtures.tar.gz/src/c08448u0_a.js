/**
 * A number, or a string containing a number.
 * @typedef {(number|string)} NumberLike
 */

/** @type {NumberLike[]} */export default ([ ]);
