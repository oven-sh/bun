0 as number;
var v = <string>undefined;
