/// <reference types="foo" resolution-mode="import" />
MODULE; // ok
SCRIPT; // error
