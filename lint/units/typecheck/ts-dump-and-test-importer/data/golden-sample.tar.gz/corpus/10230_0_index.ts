// esm format file
import { Thing } from "inner/other";
export const a = (await import("inner/index.js")).x();