function f() {
    ¬
    return;
}