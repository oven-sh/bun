class C {
   set Foo() { }
}