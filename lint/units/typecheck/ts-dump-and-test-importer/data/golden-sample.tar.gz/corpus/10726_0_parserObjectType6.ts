var v: {
   a: B
   [];
};