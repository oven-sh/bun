var A = {};
A.B = class {
    m() {
        /** @type {string[]} */
        var x = [];
        /** @type {number[]} */
        var y;
        y = x;
    }
};
