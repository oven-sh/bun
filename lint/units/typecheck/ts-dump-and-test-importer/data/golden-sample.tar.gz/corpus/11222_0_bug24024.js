// #24024
var wat = require('./bug24024')
module.exports = class C {}
module.exports.D = class D { }
