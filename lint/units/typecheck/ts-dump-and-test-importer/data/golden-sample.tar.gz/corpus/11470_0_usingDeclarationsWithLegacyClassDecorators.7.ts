export {};

declare var dec: any;

@dec
class C {
}

using after = null;
