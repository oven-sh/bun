declare class F extends E { }
var f: E = new F();
