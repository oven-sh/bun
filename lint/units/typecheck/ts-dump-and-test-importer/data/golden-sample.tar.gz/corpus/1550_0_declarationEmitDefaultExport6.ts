export class A {}
export default new A();
