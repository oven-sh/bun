var f: {
    x: number;
    <-
};