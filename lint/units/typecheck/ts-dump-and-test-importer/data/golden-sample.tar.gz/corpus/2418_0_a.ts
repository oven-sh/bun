import Namespace from "./b";
export var x = new Namespace.Foo();
