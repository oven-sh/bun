interface x {
    (): Date;
    foo: string;
}
export = x;
 