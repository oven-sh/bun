namespace server {
    export interface connectModule {
        (res, req, next): void;
    }
    export interface connectExport {
        use: (mod: connectModule) => connectExport;
    }
}
declare var server: {
    (): server.connectExport;
    foo: Date;
};
export = server;
 