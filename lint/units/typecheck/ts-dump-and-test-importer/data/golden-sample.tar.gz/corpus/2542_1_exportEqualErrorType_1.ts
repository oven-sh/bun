///<reference path='exportEqualErrorType_0.ts'/>
import connect = require('./exportEqualErrorType_0');
connect().use(connect.static('foo')); // Error  1      The property 'static' does not exist on value of type ''.
