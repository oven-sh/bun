function foo() {
}
