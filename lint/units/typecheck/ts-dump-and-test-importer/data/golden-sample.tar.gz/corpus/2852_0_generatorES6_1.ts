function* foo() {
    yield
}