declare module "foo";
