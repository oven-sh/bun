/*1*/ export /*2*/ default /*3*/ Array /*4*/;
