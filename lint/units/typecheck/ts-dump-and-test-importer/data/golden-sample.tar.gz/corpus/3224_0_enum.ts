export enum Enum {
    A,
    B
}