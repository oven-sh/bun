import {Enum} from "./enum";

import EnumA = Enum.A;

export type EnumA = [string] | [string, number];
