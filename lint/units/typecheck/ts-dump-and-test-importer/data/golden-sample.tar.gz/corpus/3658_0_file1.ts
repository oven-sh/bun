const enum E { X = 100 };
var e = E.X;
export var x;