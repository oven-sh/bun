"use strict";
var a = {
    a: "hello", // error
    b: 10,
    a: 10 // error
};
var let = 10; // error
delete a; // error
try {
} catch (eval) { // error
}
function arguments() { // error
}

with (a) {
    b = 10;
}
