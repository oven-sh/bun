export var let = 10; // external modules are automatically in strict mode
var eval = function () {
};
