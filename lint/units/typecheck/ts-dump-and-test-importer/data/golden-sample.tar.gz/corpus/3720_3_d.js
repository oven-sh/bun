"use strict";
var x = 009; // error