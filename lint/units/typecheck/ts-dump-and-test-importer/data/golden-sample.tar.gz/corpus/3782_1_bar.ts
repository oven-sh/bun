f(); // Error
f(1); // Error
f(1, 2); // Error

f(1, 2, 3); // OK
