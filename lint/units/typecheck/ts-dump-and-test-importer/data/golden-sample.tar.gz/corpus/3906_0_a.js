var elemA = 42;
