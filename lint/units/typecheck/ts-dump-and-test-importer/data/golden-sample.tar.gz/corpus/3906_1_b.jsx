var elemB = <b>{"test"}</b>;
