var elemC = <c>{42}</c>;
