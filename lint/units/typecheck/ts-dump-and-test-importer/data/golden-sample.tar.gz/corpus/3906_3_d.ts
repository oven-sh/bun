var elemD = 42;
