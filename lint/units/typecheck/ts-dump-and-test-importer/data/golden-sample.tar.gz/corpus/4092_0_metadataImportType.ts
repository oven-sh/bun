export class A {
    @test
    b: import('./b').B
}