export class B {x: number;}
