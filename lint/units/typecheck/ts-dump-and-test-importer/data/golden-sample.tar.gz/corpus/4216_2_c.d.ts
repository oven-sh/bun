declare module "C" {
    class Cls {y: string; }
}
