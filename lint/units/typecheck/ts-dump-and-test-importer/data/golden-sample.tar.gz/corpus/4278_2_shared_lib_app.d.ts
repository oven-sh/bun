import { Option } from "troublesome-lib/lib/Option";
export class SharedOption extends Option { }
export const makeSharedOption: () => SharedOption;