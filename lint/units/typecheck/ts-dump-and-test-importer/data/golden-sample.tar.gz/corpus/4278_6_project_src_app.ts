import * as t from "anotherLib"; // Include the lib that recursively includes option as relative module resolution in this directory
import { makeSharedOption } from "@shared/lib/app"; // Includes option as module in shared folder but as module in node_modules folder
