import {x} from "@speedy/folder1/testing"
