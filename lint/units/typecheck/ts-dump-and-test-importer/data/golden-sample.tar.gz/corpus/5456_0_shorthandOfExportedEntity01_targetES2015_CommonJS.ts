export const test = "test";

export function foo () {
  const x = { test };
}
