namespace m1 {
    export class c1 {
    }
}
