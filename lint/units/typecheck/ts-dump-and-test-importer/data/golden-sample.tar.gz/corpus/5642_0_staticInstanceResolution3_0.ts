export class Promise {
    static timeout(delay: number): Promise {
        return null;
    }
}
