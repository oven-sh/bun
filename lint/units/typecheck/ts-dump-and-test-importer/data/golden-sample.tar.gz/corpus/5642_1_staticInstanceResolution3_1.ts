///<reference path='staticInstanceResolution3_0.ts'/>
import WinJS = require('./staticInstanceResolution3_0');
WinJS.Promise.timeout(10);