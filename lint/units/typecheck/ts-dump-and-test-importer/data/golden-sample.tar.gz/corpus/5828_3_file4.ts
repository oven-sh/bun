export default class C {}

