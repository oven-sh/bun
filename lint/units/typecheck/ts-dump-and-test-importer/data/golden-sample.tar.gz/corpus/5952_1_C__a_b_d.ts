/// <reference path="C:\a\b\c.ts" />
const y = x + 3;