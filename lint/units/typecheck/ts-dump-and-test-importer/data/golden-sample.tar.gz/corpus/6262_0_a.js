/** @type {unique symbol} */
const foo = Symbol();

/** @typedef {{ [foo]: boolean }} A */
/** @typedef {{ [key: foo] boolean }} B */
