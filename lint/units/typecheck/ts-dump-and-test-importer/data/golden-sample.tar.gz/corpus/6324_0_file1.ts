export class Calculator {
    handleChar() {}
}

export function test() {

}

export default function test2() {

}
