import * as n from "./file1"

