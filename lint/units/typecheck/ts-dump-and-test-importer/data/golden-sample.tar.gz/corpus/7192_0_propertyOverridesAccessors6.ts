class A {
  get x() {
    return 2;
  }
}
class B extends A {}
class C extends B {
  x = 1;
}
