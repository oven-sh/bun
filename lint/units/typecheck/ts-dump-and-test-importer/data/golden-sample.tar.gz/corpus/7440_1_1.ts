"use strict"
var p1 = import("./0");
function arguments() { }