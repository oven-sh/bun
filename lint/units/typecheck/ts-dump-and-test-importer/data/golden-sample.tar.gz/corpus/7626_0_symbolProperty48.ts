namespace M {
    var Symbol;

    class C {
        [Symbol.iterator]() { }
    }
}