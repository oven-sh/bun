function f(_arguments) {
    var a = () => () => arguments;
}