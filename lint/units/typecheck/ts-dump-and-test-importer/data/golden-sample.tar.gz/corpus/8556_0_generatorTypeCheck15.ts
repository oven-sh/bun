function* g() {
    return "";
}