export {}

declare var dec: any;

// needs: __esDecorate, __runInitializers, __setFunctionName
export default @dec class {}
