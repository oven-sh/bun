export {};
declare var dec: any;

var C;

// uses __esDecorate, __runInitializers, __setFunctionName
({ C: C = @dec class {} } = {});
