Module.customJSFunctionToTestClosure = function(firstParam, secondParam) {
	console.log("This function adds two numbers to get", firstParam + secondParam);
}