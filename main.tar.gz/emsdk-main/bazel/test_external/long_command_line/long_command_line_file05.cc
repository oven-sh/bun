#include "long_command_line_file05.hh"

#include <iostream>

void f5() { std::cout << "hello from f5()\n"; }
