#include "long_command_line_file15.hh"

#include <iostream>

void f15() { std::cout << "hello from f15()\n"; }
