#!/usr/bin/env node
console.log("tool from actual-package");
