module.exports = "dep-any-libc";
