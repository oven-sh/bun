module.exports = "dep-glibc";
