module.exports = "dep-glibc@1.0.0";
