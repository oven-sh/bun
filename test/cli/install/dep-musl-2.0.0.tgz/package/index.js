module.exports = "dep-musl";
