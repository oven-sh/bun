module.exports = "dep-musl@2.0.0";
