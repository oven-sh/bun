module.exports = "dep-universal@3.0.0";
