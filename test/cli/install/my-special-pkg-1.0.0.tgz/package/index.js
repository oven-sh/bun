#!/usr/bin/env node
console.log("different-bin from my-special-pkg");
