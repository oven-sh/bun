module.exports = "7-no-deps";
