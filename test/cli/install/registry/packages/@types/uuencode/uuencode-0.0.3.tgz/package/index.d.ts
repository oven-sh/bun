export function encode(data: string): string;
