/// <reference types="node" />

declare class WebSocket {
  constructor(address: string);
  send(data: string): void;
}

export = WebSocket;
