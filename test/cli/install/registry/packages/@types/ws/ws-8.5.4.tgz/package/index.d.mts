import WebSocket = require("./index.js");
export default WebSocket;
