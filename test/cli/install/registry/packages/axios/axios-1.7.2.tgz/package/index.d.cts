declare const axios: { defaults: object; VERSION: string };
export = axios;
