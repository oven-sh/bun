declare const axios: { defaults: object; VERSION: string };
export default axios;
