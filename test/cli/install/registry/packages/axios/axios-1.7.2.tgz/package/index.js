import axios from './lib/axios.js';

const { Axios, VERSION } = axios;

export { axios as default, Axios, VERSION };
