#!/usr/bin/env node
console.log("bin-cycle-b");
