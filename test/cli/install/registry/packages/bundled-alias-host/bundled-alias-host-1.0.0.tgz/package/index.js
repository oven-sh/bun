const { name, version } = require("no-deps-cjs/package.json");
module.exports = [name + "@" + version, require("bundled-alias-inner")];
