const { name, version } = require("a-dep-cjs/package.json");
module.exports = name + "@" + version;
