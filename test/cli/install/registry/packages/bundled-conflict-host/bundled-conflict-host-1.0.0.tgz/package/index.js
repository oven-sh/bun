module.exports = [require("bundled-shipped-inner"), require("no-deps/package.json").version];
