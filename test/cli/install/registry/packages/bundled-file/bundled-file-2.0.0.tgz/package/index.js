module.exports = require("bundled-file-dep");
