module.exports = require("bundled-shipped-inner");
