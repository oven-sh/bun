module.exports = [require.resolve("no-deps/package.json"), require("bundled-peer-plugin")];
