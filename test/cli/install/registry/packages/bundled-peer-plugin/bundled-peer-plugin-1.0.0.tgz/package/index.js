module.exports = require.resolve("no-deps/package.json");
