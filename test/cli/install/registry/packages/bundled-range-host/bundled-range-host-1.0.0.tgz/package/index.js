module.exports = require("bundled-range-inner");
