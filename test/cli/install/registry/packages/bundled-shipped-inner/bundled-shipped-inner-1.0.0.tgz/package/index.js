module.exports = require("no-deps/package.json").version;
