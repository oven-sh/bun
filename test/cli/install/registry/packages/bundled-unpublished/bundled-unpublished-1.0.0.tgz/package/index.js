module.exports = {
  "unpublished-dep": require("unpublished-dep"),
};
