module.exports = {
  "a-dep": require("a-dep"),
  "no-deps": require("no-deps"),
  "unpublished-alias": require("unpublished-alias"),
  "unpublished-catalog": require("unpublished-catalog"),
  "unpublished-dep": require("unpublished-dep"),
  "unpublished-tag": require("unpublished-tag"),
  "unpublished-workspace": require("unpublished-workspace"),
};
