module.exports = {
  "no-deps": require("no-deps"),
};
