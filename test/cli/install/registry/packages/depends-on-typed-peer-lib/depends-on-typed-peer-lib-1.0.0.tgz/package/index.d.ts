export { takes } from "typed-peer-lib";
