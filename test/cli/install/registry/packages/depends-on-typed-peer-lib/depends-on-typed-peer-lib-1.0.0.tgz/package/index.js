module.exports = require("typed-peer-lib");
