#!/usr/bin/env node
console.log("bin-a 1.0.0");
