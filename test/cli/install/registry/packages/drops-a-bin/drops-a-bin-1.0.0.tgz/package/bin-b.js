#!/usr/bin/env node
console.log("bin-b 1.0.0");
