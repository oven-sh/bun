#!/usr/bin/env node
console.log("bin-a 2.0.0");
