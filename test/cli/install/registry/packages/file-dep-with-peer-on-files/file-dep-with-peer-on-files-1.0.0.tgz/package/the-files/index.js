module.exports = "the-files shipped by file-dep-with-peer-on-files";
