{'targets':[{'target_name':'x','sources':['missing.cc']}]}
