module.exports = "gypfile-false";
