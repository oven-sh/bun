'use strict';

var isOdd = require('is-odd');

module.exports = function isEven(i) {
  if (typeof i !== 'number') {
    throw new TypeError('is-even expects a number.');
  }
  return !isOdd(i);
};
