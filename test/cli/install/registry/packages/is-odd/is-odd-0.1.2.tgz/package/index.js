'use strict';

module.exports = function isOdd(i) {
  if (typeof i !== 'number') {
    throw new TypeError('is-odd expects a number.');
  }
  return !!(~~i & 1);
};
