'use strict';

module.exports = function isOdd(value) {
  const n = Math.abs(value);
  if (!Number.isInteger(n)) {
    throw new TypeError('expected an integer');
  }
  return (n % 2) === 1;
};
