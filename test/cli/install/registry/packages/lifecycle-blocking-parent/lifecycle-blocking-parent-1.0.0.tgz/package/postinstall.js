const { appendFileSync, writeFileSync } = require("fs");

if (process.env.LIFECYCLE_TEST_LOG) {
  appendFileSync(process.env.LIFECYCLE_TEST_LOG, "lifecycle-blocking-parent\n");
}
writeFileSync("built.txt", "built");
