const { appendFileSync, renameSync, writeFileSync } = require("fs");

if (process.env.LIFECYCLE_TEST_LOG) {
  appendFileSync(process.env.LIFECYCLE_TEST_LOG, "lifecycle-blocking\n");
}

const pidFile = process.env.LIFECYCLE_TEST_BLOCK;
if (pidFile) {
  writeFileSync(pidFile + ".tmp", String(process.pid));
  renameSync(pidFile + ".tmp", pidFile);
  setInterval(() => {}, 1 << 30);
} else {
  writeFileSync("built.txt", "built");
}
