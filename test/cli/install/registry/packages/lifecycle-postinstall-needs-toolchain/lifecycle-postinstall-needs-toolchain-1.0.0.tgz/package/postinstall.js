const { writeFileSync } = require("fs");
const { join } = require("path");

if (process.env.LIFECYCLE_BLOCK_PID_FILE) {
  // Tell the test which process to kill, then wait for it.
  writeFileSync(process.env.LIFECYCLE_BLOCK_PID_FILE + ".tmp", String(process.pid));
  require("fs").renameSync(process.env.LIFECYCLE_BLOCK_PID_FILE + ".tmp", process.env.LIFECYCLE_BLOCK_PID_FILE);
  setTimeout(() => {
    console.error("postinstall was not killed");
    process.exit(1);
  }, 60 * 1000);
} else if (!process.env.LIFECYCLE_TOOLCHAIN) {
  console.error("toolchain missing");
  process.exit(7);
} else {
  writeFileSync(join(__dirname, "built.txt"), "ok");
}
