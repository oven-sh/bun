const { appendFileSync, existsSync, renameSync, writeFileSync } = require("fs");
const { join } = require("path");

function build() {
  if (!process.env.LIFECYCLE_TOOLCHAIN) {
    console.error("toolchain missing");
    process.exit(7);
  }
  writeFileSync(join(__dirname, "built.txt"), "ok");
}

// one line per run of this script
if (process.env.LIFECYCLE_STARTED_FILE) appendFileSync(process.env.LIFECYCLE_STARTED_FILE, "started\n");

if (process.env.LIFECYCLE_BLOCK_PID_FILE) {
  // Tell the test which process to kill, then wait for it.
  writeFileSync(process.env.LIFECYCLE_BLOCK_PID_FILE + ".tmp", String(process.pid));
  renameSync(process.env.LIFECYCLE_BLOCK_PID_FILE + ".tmp", process.env.LIFECYCLE_BLOCK_PID_FILE);
  setTimeout(() => {
    console.error("postinstall was not killed");
    process.exit(1);
  }, 60 * 1000);
} else if (process.env.LIFECYCLE_WAIT_FOR_FILE) {
  // Keep running until the test creates this file.
  const timer = setInterval(() => {
    if (existsSync(process.env.LIFECYCLE_WAIT_FOR_FILE)) {
      clearInterval(timer);
      build();
    }
  }, 20);
} else {
  build();
}
