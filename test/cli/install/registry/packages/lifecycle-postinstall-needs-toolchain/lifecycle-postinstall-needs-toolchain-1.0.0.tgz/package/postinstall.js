const { writeFileSync } = require("fs");
const { join } = require("path");

if (!process.env.LIFECYCLE_TOOLCHAIN) {
  console.error("toolchain missing");
  process.exit(7);
}

writeFileSync(join(__dirname, "built.txt"), "ok");
