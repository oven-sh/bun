module.exports = require('./fp/_baseConvert.js')(require('./lodash.js'));
