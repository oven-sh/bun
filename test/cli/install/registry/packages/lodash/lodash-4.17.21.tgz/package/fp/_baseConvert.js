var mapping = require('./_mapping.js');
module.exports = function baseConvert(lodash) {
  return { placeholder: require('./placeholder.js'), aliases: mapping.aliasToReal, chunk: lodash.chunk };
};
