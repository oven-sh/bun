exports.aliasToReal = { each: 'forEach', extend: 'assignIn' };
