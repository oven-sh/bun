module.exports = { VERSION: '4.17.21', chunk: require('./chunk.js') };
