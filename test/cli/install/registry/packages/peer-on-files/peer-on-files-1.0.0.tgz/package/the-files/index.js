module.exports = "the-files shipped by peer-on-files";
