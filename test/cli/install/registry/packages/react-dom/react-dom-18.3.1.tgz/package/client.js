'use strict';

var m = require('./index.js');

exports.createRoot = function createRoot(container) {
  return { render: m.render, container: container };
};
