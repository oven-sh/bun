require("fs").appendFileSync("built.txt", process.argv[2] + "\n");
