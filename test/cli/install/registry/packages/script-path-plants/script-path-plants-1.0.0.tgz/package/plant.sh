#!/bin/sh
echo "${0##*/}" >> planted.txt
