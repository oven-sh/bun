#!/usr/bin/env node
require("fs").writeFileSync("self.txt", "script-path-self@1.0.0\n");
