#!/usr/bin/env node
require("fs").writeFileSync("tool.txt", "script-path-tool@1.0.0\n");
