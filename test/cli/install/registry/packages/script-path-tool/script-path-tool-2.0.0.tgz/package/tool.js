#!/usr/bin/env node
require("fs").writeFileSync("tool.txt", "script-path-tool@2.0.0\n");
