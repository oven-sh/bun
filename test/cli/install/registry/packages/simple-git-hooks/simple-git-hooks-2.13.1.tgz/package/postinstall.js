const fs = require("fs");
fs.writeFileSync("postinstall-ran", "");
fs.statSync("../../package.json");
