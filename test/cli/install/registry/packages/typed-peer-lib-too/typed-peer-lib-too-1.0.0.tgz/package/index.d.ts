import { value } from "typed-peer";
export declare function takesToo(v: typeof value): boolean;
