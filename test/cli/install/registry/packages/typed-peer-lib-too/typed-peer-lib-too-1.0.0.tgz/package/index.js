module.exports = { takesToo(v) { return require("typed-peer").value === v; } };
