import { value } from "typed-peer";
export declare function takes(v: typeof value): boolean;
