module.exports = { takes(v) { return require("typed-peer").value === v; } };
