module.exports = { ...require("typed-peer-lib"), ...require("typed-peer-lib-too") };
